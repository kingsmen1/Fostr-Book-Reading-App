const functions = require("firebase-functions");
const express = require("express");
var { RtcTokenBuilder } = require("agora-access-token");
const admin = require("firebase-admin");

const APP_ID = "58ee1103fa5b4a9e98e02bacc19aa826";
const APP_CERTIFICATE = "f04acf7d606f4a9e9b0cda33c2c60f72";
const expirationTimeInSeconds = 3600; // default
const app = express();

const roomCollection = "rooms";
const userCollection = "users";
const bookclubCollection = "bookclubs";
const amphitheatreCollection = "amphitheatre";

const generateRtcToken = function (channelName) {
    var currentTimestamp = Math.floor(Date.now() / 1000);
    var privilegeExpiredTs = currentTimestamp + expirationTimeInSeconds;
    var role = 1;
    var uid = 0;
    if (!channelName) {
        throw new Error("channelName is required");
    }

    var key = RtcTokenBuilder.buildTokenWithUid(
        APP_ID,
        APP_CERTIFICATE,
        channelName,
        uid,
        role,
        privilegeExpiredTs
    );

    return key;
};

app.post("/v1/create/:userid", async (req, res) => {
    const increment = admin.firestore.FieldValue.increment(1);
    //user document for update
    const docref = admin
        .firestore()
        .collection(userCollection)
        .doc(req.params.userid);

    try {
        const amphitheatre = req.body;
        amphitheatre["scheduledOn"] = new Date(amphitheatre["scheduledOn"]);
        const snapshot = admin
            .firestore()
            .collection(roomCollection)
            .doc(req.params.userid)
            .collection(amphitheatreCollection)
            .doc();

        const token = generateRtcToken(snapshot.id);
        await snapshot
            .create({
                ...amphitheatre,
                theatreId: snapshot.id,
                token: token,
                roomID: snapshot.id,
                authorName: amphitheatre.author,
            })
            .then(
                docref.update({
                    totalAmphitheatres: increment,
                })
            );

        if (amphitheatre.isUpcoming) {
            await admin.firestore().collection("upcomingRooms").add({
                roomId: snapshot.id,
                userId: req.params.userid,
                dateTime: amphitheatre.scheduledOn,
                isAmphitheatre: true,
                isDone: false,
            });
        }

        res.status(201).json({
            message: "Amphitheatre created successfully",
            roomId: snapshot.id,
            userId: req.params.userid,
        });
    } catch (e) {
        functions.logger.log(e);
        res.status(404).send(e);
    }
});

// //create new room under user
// app.post("/v1/create/:userid", async (req, res) => {
//     const increment = admin.firestore.FieldValue.increment(1);
//     //user document for update
//     const docref = admin
//         .firestore()
//         .collection(userCollection)
//         .doc(req.params.userid);

//     try {
//         const room = req.body;
//         room["dateTime"] = new Date(room["dateTime"]);
//         const snapshot = await admin
//             .firestore()
//             .collection(roomCollection)
//             .doc(req.params.userid)
//             .collection(roomCollection)
//             .add({
//                 ...room,
//             })
//             .then(
//                 docref
//                     .update({
//                         totalRooms: increment,
//                     })
//                     .catch((err) => {
//                         console.log(err);
//                     })
//             );

//         const token = generateRtcToken(snapshot.id);

//         await admin
//             .firestore()
//             .collection(roomCollection)
//             .doc(req.params.userid)
//             .collection(roomCollection)
//             .doc(snapshot.id)
//             .update({ roomID: snapshot.id, token: token });

//         if (room.isUpcoming) {
//             await admin.firestore().collection("upcomingRooms").add({
//                 roomId: snapshot.id,
//                 userId: req.params.userid,
//                 dateTime: room.dateTime,
//                 isAmphitheatre: false,
//                 isDone: false,
//             });
//         }
//         return res.json({
//             message: "aphitheatre created successfully",
//             theatreId: snapshot.id,
//             userId: req.params.userid,
//         });
//     } catch (e) {
//         functions.logger.log(e);
//         res.status(404).send(e);
//     }
// });

//firebase functions route initialization
exports.aphitheatrev2 = app;
