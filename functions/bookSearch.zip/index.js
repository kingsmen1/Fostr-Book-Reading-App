const functions = require("firebase-functions");
const express = require("express");

const admin = require("firebase-admin");
admin.initializeApp();

const validateFirebaseIdToken = async (req, res, next) => {
    functions.logger.log(
        "Check if request is authorized with Firebase ID token"
    );

    if (
        (!req.headers.authorization ||
            !req.headers.authorization.startsWith("Bearer ")) &&
        !(req.cookies && req.cookies.__session)
    ) {
        functions.logger.error(
            "No Firebase ID token was passed as a Bearer token in the Authorization header.",
            "Make sure you authorize your request by providing the following HTTP header:",
            "Authorization: Bearer <Firebase ID Token>",
            'or by passing a "__session" cookie.'
        );
        res.status(403).send("Unauthorized");
        return;
    }

    let idToken;
    if (
        req.headers.authorization &&
        req.headers.authorization.startsWith("Bearer ")
    ) {
        functions.logger.log('Found "Authorization" header');
        // Read the ID Token from the Authorization header.
        idToken = req.headers.authorization.split("Bearer ")[1];
    } else if (req.cookies) {
        functions.logger.log('Found "__session" cookie');
        // Read the ID Token from cookie.
        idToken = req.cookies.__session;
    } else {
        // No cookie
        res.status(403).send("Unauthorized");
        return;
    }

    try {
        const decodedIdToken = await admin.auth().verifyIdToken(idToken);
        functions.logger.log("ID Token correctly decoded", decodedIdToken);
        req.user = decodedIdToken;
        next();
        return;
    } catch (error) {
        functions.logger.error(
            "Error while verifying Firebase ID token:",
            error
        );
        res.status(403).send("Unauthorized");
        return;
    }
};

const app = express();
//use
app.use(validateFirebaseIdToken);
const booksearch = "booksearch";


//room related functions
//get all rooms
//get recent rooms top 20 that are not upcoming
app.get("/v1/book/:id", async (req, res) => {

    let docRef = admin.firestore().collection(booksearch).doc(req.params.id);
    return docRef.get().then((doc) => {  //Note the return here
        if (doc.exists) {
            //console.log(doc.id, doc.data());
            res.status(200).send(JSON.stringify({ data: { ...doc.data() } }));

        } else {
            console.log("No such document!");
            //Handle this situation the way you want! E.g. return false or throw an error
            res.status(404).send(JSON.stringify({ data: { "bookid": "", "booktitle": "" } }));
        }
    }).catch(error => {
        console.log("Error getting document:", error);
        //Handle this situation the way you want
        res.status(500).send(JSON.stringify({ data: { "bookid": "", "booktitle": "" } }));
    });


});


app.get("/v1/activitiesbybook/:id", async (req, res) => {
    let snapshot = await admin.
        firestore().
        collection(booksearch).
        doc(req.params.id).
        collection("activities").get();

    //console.log(docRef.size);   
    let activities = [];
    snapshot.forEach((doc) => {
        let docid = doc.id;
        let activitydata = doc.data();
        //console.log(roomdata);
        activities.push({ docid, ...activitydata });
    });


    res.status(200).send(JSON.stringify({ data: activities }));
});


app.put("/v1/saveactivitytobook/:id", async (req, res) => {
    try {
        const body = req.body;
        await admin.
            firestore().
            collection(booksearch).
            doc(req.params.id).
            collection("activities").add(body);

        res.status(200).send(JSON.stringify({ "result": "success" }));
    } catch (e) {
        functions.logger.log(e);
        res.status(404).send(e);
    }

});


//firebase functions route initialization
exports.booksearch = functions.https.onRequest(app);
