const functions = require("firebase-functions");
const express = require("express");
const axios = require("axios").default;

const admin = require("firebase-admin");
admin.initializeApp();

const RecorindgRouter = require("./recorder");

const validateFirebaseIdToken = async (req, res, next) => {
    functions.logger.log(
        "Check if request is authorized with Firebase ID token"
    );

    if (
        (!req.headers.authorization ||
            !req.headers.authorization.startsWith("Bearer ")) &&
        !(req.cookies && req.cookies.__session)
    ) {
        functions.logger.error(
            "No Firebase ID token was passed as a Bearer token in the Authorization header.",
            "Make sure you authorize your request by providing the following HTTP header:",
            "Authorization: Bearer <Firebase ID Token>",
            'or by passing a "__session" cookie.'
        );
        res.status(403).send("Unauthorized");
        return;
    }

    let idToken;
    if (
        req.headers.authorization &&
        req.headers.authorization.startsWith("Bearer ")
    ) {
        functions.logger.log('Found "Authorization" header');
        // Read the ID Token from the Authorization header.
        idToken = req.headers.authorization.split("Bearer ")[1];
    } else if (req.cookies) {
        functions.logger.log('Found "__session" cookie');
        // Read the ID Token from cookie.
        idToken = req.cookies.__session;
    } else {
        // No cookie
        res.status(403).send("Unauthorized");
        return;
    }

    try {
        const decodedIdToken = await admin.auth().verifyIdToken(idToken);
        functions.logger.log("ID Token correctly decoded", decodedIdToken);
        req.user = decodedIdToken;
        next();
        return;
    } catch (error) {
        functions.logger.error(
            "Error while verifying Firebase ID token:",
            error
        );
        res.status(403).send("Unauthorized");
        return;
    }
};

//app definition
const app = express();

//route
app.use("/recording", RecorindgRouter);

//firebase functions route initialization
exports.recordingapis = functions.https.onRequest(app);

exports.getData = functions.https.onRequest(async (req, res) => {
    const rsss = await admin
        .firestore()
        .collection("users")
        .doc("eb3hOofUtqUGXk0XrXLxZ1IFpQ13")
        .get();

    res.send(rsss.data());
});

const APP_ID = "58ee1103fa5b4a9e98e02bacc19aa826";
const CUSTOMER_ID = "f7b1c0b7632647f4b1ef5f59c4a0ebf8";
const CUSTOMER_SECRET = "fe58b2a0577c4307a67c634f7a2027d6";
const MODE_TYPE = "mix";

const AUTH_CREDENTIALS = Buffer.from(
    CUSTOMER_ID + ":" + CUSTOMER_SECRET
).toString("base64");

const HEADERS = {
    "Content-Type": "application/json",
    Authorization: "Basic " + AUTH_CREDENTIALS,
};

exports.stopRecordingOnRequest = functions.https.onRequest(async (req, res) => {
    try {
        const data = {
            recording: false,
            sid: "0ad400c60d45cbe602e3a890b6979a22",
            cname: "XNhk6fbAFCmxHjE5KKuf",
            uid: "222222",
            resourceId:
                "ZialC_XNUm9LxsfzmlRowHrANFCLIwja9o0dZvDPrEj0yWRuWeLeVnbvFHT6jTaiUsI3LlvJFDEWZuxscOuqfmFE2-3qWhjZg28o_w8ENlucuMRYt0OzWWx3spHO6wa6ztrypuYwU7stO05vdjl4sC7H_VReTrmyeJxEBJH_JUpMxI9fSou-h7W0EnI-U10cdXdF4Fa5ZlSl-7KY4q9LJ8pvjSO6eDwvatgGHLRT3RuCsCCHX5Z4YZFRy0rlriFV",
            token: "00658ee1103fa5b4a9e98e02bacc19aa826IADGnYexUU/uJT4pj5/XFiQ35LBz3RjjqSUvTtguzsFD86w2ar0AAAAAIgB24Ax4dOaYYgQAAQAEo5diAgAEo5diAwAEo5diBAAEo5di",
        };
        const theatreId = "XNhk6fbAFCmxHjE5KKuf";
        const userId = "DpFWnOIYqRasdBZWBeY34BMlpWt2";
        if (data.recording === false) {
            const { sid, cname, uid, resourceId } = data;

            const url = `https://api.agora.io/v1/apps/${APP_ID}/cloud_recording/resourceid/${resourceId}/sid/${sid}/mode/${MODE_TYPE}/stop`;
            const payload = {
                cname,
                uid,
                clientRequest: {},
            };

            const response = await axios.post(url, payload, {
                headers: HEADERS,
            });

            if (response.status === 200) {
                await admin.firestore().collection("recordings").add({
                    roomId: theatreId,
                    userId: userId,
                    resourceId: resourceId,
                    sid: sid,
                    uid: uid,
                    cname: cname,
                    token: data.token,
                    isActive: true,
                    type: "AMPHITHEATRE",
                    fileName:
                        response.data["serverResponse"]["fileList"][0][
                            "fileName"
                        ],
                    dateTime: admin.firestore.FieldValue.serverTimestamp(),
                });
                return res.json({ staus: "ok", data: response.data });
            } else {
                return res.json({ staus: "error", data: response.data });
            }
        }
    } catch (error) {
        console.log(error);
        return res.json({ staus: "error", data: response.data });
    }
});
