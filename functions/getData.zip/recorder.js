const { RtcTokenBuilder, RtcRole } = require("agora-access-token");
const express = require("express");
const axios = require("axios").default;
const router = express.Router();
const admin = require("firebase-admin");

const roomCollection = admin.firestore().collection("rooms");

const expirationTimeInSeconds = 3600;
const APP_CERTIFICATE = "f04acf7d606f4a9e9b0cda33c2c60f72";
const APP_ID = "58ee1103fa5b4a9e98e02bacc19aa826";
const CUSTOMER_ID = "f7b1c0b7632647f4b1ef5f59c4a0ebf8";
const CUSTOMER_SECRET = "fe58b2a0577c4307a67c634f7a2027d6";
const BASE_URL = "https://api.agora.io/dev/v1";
const MODE_TYPE = "mix";

const AUTH_CREDENTIALS = Buffer.from(
    CUSTOMER_ID + ":" + CUSTOMER_SECRET
).toString("base64");

const HEADERS = {
    "Content-Type": "application/json",
    Authorization: "Basic " + AUTH_CREDENTIALS,
};

router.route("/channels").get(async (req, res) => {
    try {
        const url = BASE_URL + "/channel/" + APP_ID;
        const response = await axios.get(url, { headers: HEADERS });
        if (response.status === 200) {
            return res.json({ staus: "success", data: response.data });
        } else {
            return res.json({ staus: "error", data: response.data });
        }
    } catch (error) {
        return res.json({ status: "error", message: error.message });
    }
});

const getRecordingId = async (channelName) => {
    const url = BASE_URL + "/channel/user/" + APP_ID + "/" + channelName;
    const response = await axios.get(url, { headers: HEADERS });
    if (response.status === 200) {
        return response.data.data.broadcasters[0];
    }
    throw new Error(response.data.message);
};

const getResourceId = async (cname, uid) => {
    const url = `https://api.agora.io/v1/apps/${APP_ID}/cloud_recording/acquire`;

    const response = await axios.post(
        url,
        {
            cname: cname.toString(),
            uid: uid.toString(),
            clientRequest: {
                resourceExpiredHour: 24,
                scene: 0,
            },
        },
        {
            headers: HEADERS,
        }
    );

    if (response.status === 200) {
        return response.data.resourceId;
    }
    throw new Error(response.data.message);
};

const generateRtcToken = async (channelName) => {
    var currentTimestamp = Math.floor(Date.now() / 1000);
    var privilegeExpiredTs = currentTimestamp + expirationTimeInSeconds;

    var uid = 0;
    var role = 1;
    if (!channelName) {
        throw new Error("channel name is required");
    }

    const key = RtcTokenBuilder.buildTokenWithUid(
        APP_ID,
        APP_CERTIFICATE,
        channelName,
        uid,
        RtcRole.PUBLISHER,
        privilegeExpiredTs
    );

    return key;
};

router.route("/channels/:channel_id/start/").get(async (req, res) => {
    try {
        const cname = req.params.channel_id;
        const uid = "222222";
        const resourceId = await getResourceId(cname, uid);

        const url = `https://api.agora.io/v1/apps/${APP_ID}/cloud_recording/resourceid/${resourceId}/mode/${MODE_TYPE}/start`;

        const token = await generateRtcToken(cname);

        const payload = {
            cname: cname.toString(),
            uid: uid.toString(),
            clientRequest: {
                // token: "00658ee1103fa5b4a9e98e02bacc19aa826IABaqf6PBucxEbRCMfbdDqp1nxCUv0Hz5d0QQaaf90u/TZSQPX0AAAAAEAATYs86ayJkYgEAAQD73mJi",
                token: token,
                recordingConfig: {
                    channelType: 1,
                    streamTypes: 0,
                    // audioProfile: 1,
                    videoStreamType: 0,
                    maxIdleTime: 120,
                },
                recordingFileConfig: {
                    avFileType: ["hls", "mp4"],
                },
                storageConfig: {
                    vendor: 6,
                    region: 0,
                    bucket: "fostercloudrecordings",
                    accessKey: "GOOGEDDY2FUS6UZKL4XSAY34",
                    secretKey: "W4TDVJ1p4bkb+AZ+63dsH3syw2MbGCZ8UbI705Nr",
                    fileNamePrefix: ["rooms"],
                },
            },
        };

        const response = await axios.post(url, payload, {
            headers: HEADERS,
        });
        if (response.status === 200) {
            return res.json({
                staus: "success",
                data: {
                    ...response.data,
                    token: token,
                    uid: uid.toString(),
                    cname: cname.toString(),
                },
            });
        } else {
            return res.json({ staus: "error", data: response.data });
        }
    } catch (error) {
        console.log(error.response);
        return res.json({ status: "error", message: error.message });
    }
});

router
    .route("/channels/:channel_id/:recording_id/:resource_id/:sid/update")
    .post(async (req, res) => {
        try {
            const cname = req.params.channel_id;
            const uid = req.params.recording_id;
            const resourceId = req.params.resource_id;
            const sid = req.params.sid;

            const url = `https://api.agora.io/v1/apps/${APP_ID}/cloud_recording/resourceid/${resourceId}/sid/${sid}/mode/${MODE_TYPE}/update`;
            const data = JSON.parse(req.body);
            const uids = data.uids.map((id) => id.toString());
            console.log(uids);
            const payload = {
                cname: cname,
                uid: uid.toString(),
                clientRequest: {
                    streamSubscribe: {
                        audioUidList: {
                            subscribeAudioUids: uids,
                        },
                    },
                },
            };

            const response = await axios.post(url, payload, {
                headers: HEADERS,
            });

            if (response.status === 200) {
                return res.json({
                    staus: "success",
                    data: {
                        ...response.data,
                        uid: uid.toString(),
                        cname: cname.toString(),
                    },
                });
            } else {
                return res.json({ staus: "error", data: response.data });
            }
        } catch (error) {
            console.log(error.response);
            return res.json({ status: "error", message: error.message });
        }
    });

router
    .route("/channels/:channel_id/:recording_id/:resource_id/:sid/stop")
    .get(async (req, res) => {
        try {
            const cname = req.params.channel_id;
            const uid = req.params.recording_id;
            const resourceId = req.params.resource_id;
            const sid = req.params.sid;

            const url = `https://api.agora.io/v1/apps/${APP_ID}/cloud_recording/resourceid/${resourceId}/sid/${sid}/mode/${MODE_TYPE}/stop`;

            const payload = {
                cname,
                uid,
                clientRequest: {},
            };

            const response = await axios.post(url, payload, {
                headers: HEADERS,
            });

            if (response.status === 200) {
                return res.json({ staus: "success", data: response.data });
            } else {
                return res.json({ staus: "error", data: response.data });
            }
        } catch (error) {
            console.log(error.response.data);
            console.log(error.message);
            return res.json({ status: "error", message: error.message });
        }
    });

router.route("/stop/:type/:userId/:roomId").get(async (req, res) => {
    try {
        const { type, userId, roomId } = req.params;
        let data = {};
        if (type === "ROOM") {
            data = (
                await roomCollection
                    .doc(userId)
                    .collection("rooms")
                    .doc(roomId)
                    .get()
            ).data();
        } else if (type === "AMPHITHEATRE") {
            data = (
                await roomCollection
                    .doc(userId)
                    .collection("amphitheatre")
                    .doc(roomId)
                    .get()
            ).data();
        }
        if (data.recording === true) {
            const { sid, cname, uid, resourceId } = data;

            const url = `https://api.agora.io/v1/apps/${APP_ID}/cloud_recording/resourceid/${resourceId}/sid/${sid}/mode/${MODE_TYPE}/stop`;
            const payload = {
                cname,
                uid,
                clientRequest: {},
            };

            const response = await axios.post(url, payload, {
                headers: HEADERS,
            });

            if (response.status === 200) {
                await admin.firestore().collection("recordings").add({
                    roomId: roomId,
                    userId: userId,
                    resourceId: resourceId,
                    sid: sid,
                    uid: uid,
                    cname: cname,
                    token: data.token,
                    isActive: true,
                    type: type,
                    fileName:
                        response.data["serverResponse"]["fileList"][0][
                            "fileName"
                        ],
                    dateTime: admin.firestore.FieldValue.serverTimestamp(),
                });
                return res.json({ staus: "ok", data: response.data });
            } else {
                return res.json({ staus: "error", data: response.data });
            }
        }
    } catch (error) {
        return res.json({ staus: "error", data: error });
    }
});

module.exports = router;
