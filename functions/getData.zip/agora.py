import base64
import resource
import requests

appid = '58ee1103fa5b4a9e98e02bacc19aa826'
customerid = 'f7b1c0b7632647f4b1ef5f59c4a0ebf8'
customersecret = 'fe58b2a0577c4307a67c634f7a2027d6'
consolebaseurl = 'https://api.agora.io/dev/v1/'
modetype='mix'

authcredentials = base64.b64encode(f"{customerid}:{customersecret}".encode()).decode()
headers = {"Authorization": f'Basic {authcredentials}',"Content-Type": "application/json"}



#get channels
url = f'{consolebaseurl}channel/{appid}'
response = requests.get(url,headers=headers)
response.status_code
response.json()

#list of users in channel
channelname="FosterReadsTechTalks"
url = f"{consolebaseurl}channel/user/{appid}/{channelname}"
response = requests.get(url,headers=headers)
response.status_code
result = response.json()
recordinguid = result.get('data').get('broadcasters')[0]
print(recordinguid)

#acquire recording resource id 
url = f"https://api.agora.io/v1/apps/{appid}/cloud_recording/acquire"
payload={
  "cname": f"{channelname}",
  "uid": f"{recordinguid}",
  "clientRequest":{
  }
}
response = requests.post(url,headers=headers,json=payload)
response.status_code
result = response.json()
resourceid = result.get('resourceId')
print(resourceid)


#start recording this should be done within 5 minutes from obtaining the resourceID

#storage config derived from here https://docs.agora.io/en/cloud-recording/cloud_recording_api_start?platform=RESTful#cloud-storage-configuration

url = f"https://api.agora.io/v1/apps/{appid}/cloud_recording/resourceid/{resourceid}/mode/{modetype}/start"

payload = {
	"cname":f"{channelname}",
	"uid":f"{recordinguid}",
	"clientRequest":{
        "token": "00658ee1103fa5b4a9e98e02bacc19aa826IABaqf6PBucxEbRCMfbdDqp1nxCUv0Hz5d0QQaaf90u/TZSQPX0AAAAAEAATYs86ayJkYgEAAQD73mJi", 
		"recordingConfig":{
			"channelType":0,
			"streamTypes":2,	
			"audioProfile":1,
			"videoStreamType":0,
			"maxIdleTime":120,
			"transcodingConfig":{
				"width":360,
				"height":640,
				"fps":30,
				"bitrate":600,
				"maxResolutionUid":"1",
				"mixedVideoLayout":1
				}
			},
		"storageConfig":{
			"vendor":6,
			"region":0,
			"bucket":"fostercloudrecordings",
			"accessKey":"GOOGEDDY2FUS6UZKL4XSAY34",
			"secretKey":"W4TDVJ1p4bkb+AZ+63dsH3syw2MbGCZ8UbI705Nr",
			"fileNamePrefix":["rooms"]
		}	
	}
} 
response = requests.post(url,headers=headers,json=payload)
response.status_code
result = response.json()
recordingstartsid= result.get('sid')
print(f"responsestatuscode : {response.status_code} , recordingstartsid {recordingstartsid}")
#stop recording 

url=f"https://api.agora.io/v1/apps/{appid}/cloud_recording/resourceid/{resourceid}/sid/{recordingstartsid}/mode/{modetype}/stop"

payload={
  "cname": f"{channelname}",
  "uid": f"{recordinguid}",
  "clientRequest":{
  }
}

response = requests.post(url,headers=headers,json=payload)
print(response.status_code)
result = response.json()
print(result)

"""
{'resourceId': 'nUwUbQf9Zg6tsgtLslGnDg0lk8RYaUE09pqOuSIgwfwdo9oWOI4Ooy78YkDxZ_LBLE-6EnE_K0ENMu3T0YIOAatduTO2oUULUsFthW-3fIZnOKDO9tOTVbZQ0ONV3-eE8kl2a-2M-lHeFB_LuE5m80RAXvXW1sQvEkYyVg8CKYVoxPO5NNCcuU_dIlUdhUH1g9z71dBMh_Hl8b4wut2LJfoEHHxJh1Qht567P4zGHyiEVyDRDjgY2kPcF14eBinbBoSYrilpJt0TlhyoPL5kayMid9gFO-5atNnlxVsNnVRJ8Ic1MCMTz4EZ8jPT02vnMjwbOrKRODNxgi21UND-idgPnLjrVFZqYcSGvi35EGoRHgVhIL40SI0qqxrA9gjEClaaNkTKvva5SW8VG70l5A',
 'sid': '8bae02a33c4a0e90b035a689ec4f2977',
 'code': 404,
 'serverResponse': {'command': 'StopCloudRecorder',
  'payload': {'message': 'Failed to find worker.'},
  'subscribeModeBitmask': 1,
  'vid': '469753'}}
"""

