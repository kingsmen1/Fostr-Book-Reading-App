const functions = require("firebase-functions");
const admin = require("firebase-admin");

admin.initializeApp({
    credential: admin.credential.applicationDefault(),
});

const db = admin.firestore();

const adsCollection = db.collection("advertisements");

exports.getRandomAd = functions.https.onCall(async (data, context) => {
    try {
        const { userId } = data;
        const res = await adsCollection.get();

        // let maxTry = data.maxTry || 5;

        let randomUserRef = res.docs[0].ref;

        const randomUserId = Math.floor(Math.random() * res.docs.length);
        randomUserRef = res.docs[randomUserId].ref;
        const ads = await randomUserRef.collection("ads").get();

        const randomAdId = Math.floor(Math.random() * ads.docs.length);

        const randomAdRef = ads.docs[randomAdId].ref;
        const randomAd = ads.docs[randomAdId].data();

        randomAdRef.update({
            impressions: admin.firestore.FieldValue.increment(1),
        });
        randomUserRef.update({
            impressions: admin.firestore.FieldValue.increment(1),
        });
        randomUserRef.collection("logs").add({
            userId,
            event: "impression",
            adId: randomAd.id,
            createdAt: admin.firestore.FieldValue.serverTimestamp(),
        });

        return {
            ad: randomAd,
            freq: 5,
        };
    } catch (error) {
        return {
            error: error.message,
        };
    }
});

exports.updateAdClicks = functions.https.onCall(async (data, _) => {
    try {
        const { userId, adId, adUserId } = data;

        adsCollection.doc(adUserId).update({
            clicks: admin.firestore.FieldValue.increment(1),
        });

        adsCollection.doc(adUserId).collection("logs").add({
            userId,
            event: "click",
            adId,
            createdAt: admin.firestore.FieldValue.serverTimestamp(),
        });

        adsCollection
            .doc(adUserId)
            .collection("ads")
            .doc(adId)
            .update({
                clicks: admin.firestore.FieldValue.increment(1),
            });
        return {
            success: true,
        };
    } catch (err) {
        return {
            error: err.message,
        };
    }
});
