const functions = require("firebase-functions");
const admin = require("firebase-admin");
admin.initializeApp();
const auth = admin.app().auth();

exports.getUsers = functions.https.onRequest(async (req, res) => {
    // get all users who created account from email
    const users = await auth.listUsers();
    const data = users.users.filter((user) => !user.emailVerified);
    res.send(data);
});

exports.isUserExist = functions.https.onCall(async (req, res) => {
    const { phoneNumber } = req.body;
    try {
        const user = await auth.getUserByPhoneNumber(phoneNumber);
        if (!user) {
            return res.json({
                isExist: false,
            });
        }
        return res.json({
            isExist: true,
        });
    } catch (error) {
        return res.json({
            isExist: false,
        });
    }
});
