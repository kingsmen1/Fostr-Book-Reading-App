const functions = require("firebase-functions");
const express = require("express");
const cors = require("cors");
const admin = require("firebase-admin");
admin.initializeApp();
const fcm = admin.messaging();

const validateFirebaseIdToken = async (req, res, next) => {
    functions.logger.log(
        "Check if request is authorized with Firebase ID token"
    );

    if (
        (!req.headers.authorization ||
            !req.headers.authorization.startsWith("Bearer ")) &&
        !(req.cookies && req.cookies.__session)
    ) {
        functions.logger.error(
            "No Firebase ID token was passed as a Bearer token in the Authorization header.",
            "Make sure you authorize your request by providing the following HTTP header:",
            "Authorization: Bearer <Firebase ID Token>",
            'or by passing a "__session" cookie.'
        );
        res.status(403).send("Unauthorized");
        return;
    }

    let idToken;
    if (
        req.headers.authorization &&
        req.headers.authorization.startsWith("Bearer ")
    ) {
        functions.logger.log('Found "Authorization" header');
        // Read the ID Token from the Authorization header.
        idToken = req.headers.authorization.split("Bearer ")[1];
    } else if (req.cookies) {
        functions.logger.log('Found "__session" cookie');
        // Read the ID Token from cookie.
        idToken = req.cookies.__session;
    } else {
        // No cookie
        res.status(403).send("Unauthorized");
        return;
    }

    try {
        const decodedIdToken = await admin.auth().verifyIdToken(idToken);
        functions.logger.log("ID Token correctly decoded", decodedIdToken);
        req.user = decodedIdToken;
        next();
        return;
    } catch (error) {
        functions.logger.error(
            "Error while verifying Firebase ID token:",
            error
        );
        res.status(403).send("Unauthorized");
        return;
    }
};

const app = express();
//use
app.use(validateFirebaseIdToken);

const bookClubCollection = "bookclubs";
const userCollection = "users";
const roomCollection = "rooms";

//get recently created bookclubs
//get recent rooms top 20 that are not upcoming
app.get("/v1/recent", async (req, res) => {
    const snapshot = await admin
        .firestore()
        .collectionGroup(bookClubCollection)
        .where("isActive", "==", true)
        .orderBy("dateTime", "desc")
        .limit(20) // restrict to 10 records
        .get();

    //console.log(snapshot.size);
    let rooms = [];
    snapshot.forEach((doc) => {
        let roomId = doc.id;
        let roomdata = doc.data();
        //console.log(roomdata);
        rooms.push({ roomId, ...roomdata });
    });

    res.status(200).send(JSON.stringify({ data: rooms }));
});

//update bookClub by ID
app.put("/v1/update/:id", async (req, res) => {
    const body = req.body;

    const snapshot = await admin
        .firestore()
        .collection(bookClubCollection)
        .doc(req.params.id)
        .update(body);

    res.status(200).send();
});

//create new bookClub
app.post("/v1/create", async (req, res) => {
    try {
        const bookclub = req.body;
        const docRef = admin.firestore().collection(bookClubCollection).doc();
        docRef.create({
            ...bookclub,
            id: docRef.id,
        });

        res.status(201).send();
    } catch (e) {
        console.log(e);
        res.status(404).send();
    }
});

//follow bookclub non-duplicate followers
//we will automatically increment the membercount field here .
app.post("/v1/follow/:bookclubid/:userid", async (req, res) => {
    const increment = admin.firestore.FieldValue.increment(1);
    await admin
        .firestore()
        .collection(bookClubCollection)
        .doc(req.params.bookclubid)
        .update({
            members: admin.firestore.FieldValue.arrayUnion(req.params.userid),
            membersCount: increment,
        });

    const user = (
        await admin
            .firestore()
            .collection(userCollection)
            .doc(req.params.userid)
            .get()
    ).data();

    fcm.subscribeToTopic(
        user.deviceToken || user.notificationToken,
        req.params.bookclubid
    );

    res.status(201).send();
});

//unfollow bookclub :
//we will automatically decrement the membercount . And because there is no way for the arrayRemove to
//validate if the user exists in the array even if the user is not there , the decrement will fire anyway
//CAUTION : Please only allow user to un-follow the bookclubs that they are following .
app.post("/v1/unfollow/:bookclubid/:userid", async (req, res) => {
    const decrement = admin.firestore.FieldValue.increment(-1);
    await admin
        .firestore()
        .collection(bookClubCollection)
        .doc(req.params.bookclubid)
        .update({
            members: admin.firestore.FieldValue.arrayRemove(req.params.userid),
            membersCount: decrement,
        });

    const user = (
        await admin
            .firestore()
            .collection(userCollection)
            .doc(req.params.userid)
            .get()
    ).data();

    fcm.unsubscribeFromTopic(
        user.deviceToken || user.notificationToken,
        req.params.bookclubid
    );

    res.status(201).send();
});

//firebase functions route initialization
exports.bookclubs = functions.https.onRequest(app);

// // Create and Deploy Your First Cloud Functions
// // https://firebase.google.com/docs/functions/write-firebase-functions
//
/*
exports.helloWorld = functions.https.onRequest((request, response) => {
  response.send("Hello from Firebase!");

});
*/
