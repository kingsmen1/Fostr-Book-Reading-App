const { initStorage } = require("./base/storage.service");
const { initRealtimeDB } = require("./base/realtimedb.service");
const { initFirestore } = require("./base/firestore.service");
const { handleErrors } = require("../utils/ErrorHandler");
const { FieldValue } = require("firebase-admin/firestore");

const storage = initStorage();
const firestore = initFirestore("posts");
const realtimeDB = initRealtimeDB("Posts");

exports.uploadFile = async (file, path) => {
    try {
        const res = await storage.uploadFile(file, path);
        return res;
    } catch (error) {
        handleErrors(error);
    }
};

exports.getFileURL = async (path) => {
    try {
        const res = await storage.getFile(path);
        return res;
    } catch (error) {
        handleErrors(error);
    }
};

exports.addComment = async (postId, comment) => {
    try {
        const result = await realtimeDB.addData(`${postId}/comments`, comment);
        const firebaseResult = await firestore.update({
            id: postId,
            comments: FieldValue.increment(1),
        });
        return { result, firebaseResult };
    } catch (error) {
        handleErrors(error);
    }
};

exports.getAllComments = async (postId) => {
    try {
        const result = await realtimeDB.getData(`${postId}/comments`);
        return result;
    } catch (error) {
        handleErrors(error);
    }
};

exports.removeComment = async (postId, comment) => {
    try {
        const result = await realtimeDB.deleteData(
            `${postId}/comments/${comment}`
        );

        const firebaseResult = await firestore.update({
            id: postId,
            comments: FieldValue.increment(-1),
        });

        return { result, firebaseResult };
    } catch (error) {
        handleErrors(error);
    }
};

exports.addLike = async (postId, userId, like) => {
    try {
        const result = await realtimeDB.addData(
            `${postId}/likes/${userId}`,
            like
        );

        const firebaseResult = await firestore.update({
            id: postId,
            likes: FieldValue.increment(1),
        });

        return { result, firebaseResult };
    } catch (error) {
        handleErrors(error);
    }
};

exports.getAllLikes = async (postId) => {
    try {
        const result = await realtimeDB.getData(`${postId}/likes`);
        return result;
    } catch (error) {
        handleErrors(error);
    }
};

exports.removeLike = async (postId, userId) => {
    try {
        const result = await realtimeDB.deleteData(`${postId}/likes/${userId}`);

        const firebaseResult = await firestore.update({
            id: postId,
            likes: FieldValue.increment(-1),
        });

        return { result, firebaseResult };
    } catch (error) {
        handleErrors(error);
    }
};

exports.addPost = async (post) => {
    try {
        const result = await firestore.create(post);
        return result;
    } catch (error) {
        handleErrors(error);
    }
};

exports.getAllPosts = async () => {
    try {
        const result = await firestore.getDB
            .collection("posts")
            .where("isActive", "==", true)
            .orderBy("dateTime", "asc")
            .get();
        const data = result.docs.map((doc) => doc.data());
        return data;
    } catch (error) {
        handleErrors(error);
    }
};

exports.deletePosts = async (id) => {
    try {
        const result = await firestore.update({ id, isActive: false });
        return result;
    } catch (error) {
        handleErrors(error);
    }
};
