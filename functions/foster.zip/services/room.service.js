const { initFirestore } = require("./base/firestore.service");
const { handleErrors } = require("../utils/ErrorHandler");
const { FieldValue } = require("firebase-admin/firestore");

const firestore = initFirestore("rooms");

exports.addRoom = async (room) => {
    try {
        path = `rooms/${room.userId}/rooms`;
        const result = await firestore.createAtPath(path, room);
        await result.update({
            roomId: result.id,
        });
        return result;
    } catch (error) {
        handleErrors(error);
    }
};

exports.getRoom = async (userId, roomId) => {
    try {
        const room = await firestore.getDB
            .collection("rooms")
            .doc(userId)
            .collection("rooms")
            .doc(roomId)
            .get();
        return room.data();
    } catch (error) {
        handleErrors(error);
    }
};

exports.deleteRoom = async (userId, roomId) => {
    try {
        const room = await firestore.getDB
            .collection("rooms")
            .doc(userId)
            .collection("rooms")
            .doc(roomId)
            .delete();
        return room;
    } catch (error) {
        handleErrors(error);
    }
};

exports.getRoomSpeakers = async (userId, roomId) => {
    try {
        const result = await firestore.getDB
            .collection("rooms")
            .doc(userId)
            .collection("rooms")
            .doc(roomId)
            .collection("speakers")
            .get();
        if (result.docs.length) {
            return result.docs.map((doc) => doc.data());
        } else {
            return [];
        }
    } catch (error) {
        handleErrors(error);
    }
};

exports.addRoomSpeaker = async ({ userId, roomId, speaker }) => {
    try {
        const room = await firestore.getDB
            .collection("rooms")
            .doc(userId)
            .collection("rooms")
            .doc(roomId);

        const result = await room
            .collection("speakers")
            .doc(speaker.userName)
            .set(speaker);

        room.update({
            speakerCount: FieldValue.increment(1),
        });

        return result;
    } catch (error) {
        handleErrors(error);
    }
};

exports.leaveSpeakerRoom = async ({ userId, roomId, speaker }) => {
    try {
        const room = firestore.getDB
            .collection("rooms")
            .doc(userId)
            .collection("rooms")
            .doc(roomId);

        const result = await room
            .collection("speakers")
            .doc(speaker.userName)
            .delete();

        room.update({
            speakerCount: FieldValue.increment(-1),
        });

        return result;
    } catch (error) {
        handleErrors(error);
    }
};

exports.getRoomParticipants = async (userId, roomId) => {
    try {
        const result = await firestore.getDB
            .collection("rooms")
            .doc(userId)
            .collection("rooms")
            .doc(roomId)
            .collection("participants")
            .get();
        if (result.docs.length) {
            const data = result.docs.map((doc) => doc.data());
            return data;
        } else {
            return [];
        }
    } catch (error) {
        handleErrors(error);
    }
};

exports.addRoomParticipant = async ({ userId, roomId, participant }) => {
    try {
        const room = firestore.getDB
            .collection("rooms")
            .doc(userId)
            .collection("rooms")
            .doc(roomId);

        const result = await room
            .collection("participants")
            .doc(participant.userName)
            .set(participant);

        room.update({
            participantCount: FieldValue.increment(1),
        });

        return result;
    } catch (error) {
        handleErrors(error);
    }
};

exports.leaveParticipantRoom = async ({ userId, roomId, participant }) => {
    try {
        const room = firestore.getDB
            .collection("rooms")
            .doc(userId)
            .collection("rooms")
            .doc(roomId);

        const result = await room
            .collection("participants")
            .doc(participant.userName)
            .delete();

        room.update({
            participantCount: FieldValue.increment(-1),
        });

        return result;
    } catch (error) {
        handleErrors(error);
    }
};
