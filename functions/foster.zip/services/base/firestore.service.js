const firebaseAdmin = require("firebase-admin");
const { handleErrors } = require("../../utils/ErrorHandler");

const app = firebaseAdmin.app();
const db = app.firestore();

class DBService {
    constructor(collection) {
        this.db = db.collection(collection);
    }

    getDB = db;

    filedValueIncrement(value) {
        return firebaseAdmin.firestore.FieldValue.increment(value);
    }

    filedValueDecrement(value) {
        return firebaseAdmin.firestore.FieldValue.increment(-value);
    }

    async get(id) {
        try {
            return await this.db.doc(id).get();
        } catch (error) {
            handleErrors(error);
        }
    }

    async getAll() {
        try {
            return await this.db.get();
        } catch (error) {
            handleErrors(error);
        }
    }

    async getFromLast3Days() {
        try {
            return await this.db
                .where(
                    "dateTime",
                    ">",
                    new Date(Date.now() - 3 * 24 * 60 * 60 * 1000)
                )
                .limit(100)
                .get();
        } catch (error) {
            handleErrors(error);
        }
    }

    async getAllByPath(path) {
        try {
            return await db.collection(path).get();
        } catch (error) {
            handleErrors(error);
        }
    }

    async getAllBy(query) {
        try {
            return await this.db
                .where(query.field, query.operator, query.value)
                .get();
        } catch (error) {
            handleErrors(error);
        }
    }

    async getAllByMultiple(query) {
        try {
            return await this.db
                .where(query.field, query.operator, query.value)
                .get();
        } catch (error) {
            handleErrors(error);
        }
    }

    async create(data) {
        try {
            const res = await this.db.doc(data.id).set(data);
            return res;
        } catch (error) {
            console.log(error);
            handleErrors(error);
        }
    }

    async createAtPath(path, data) {
        try {
            return await db.collection(path).add(data);
        } catch (error) {
            console.log(error);
            handleErrors(error);
        }
    }

    async update(data) {
        try {
            return await this.db.doc(data.id).update(data);
        } catch (error) {
            handleErrors(error);
        }
    }

    async delete(id) {
        try {
            return await this.db.doc(id).delete();
        } catch (error) {
            handleErrors(error);
        }
    }
}

exports.initFirestore = (collection) => {
    return new DBService(collection);
};
