const firebaseAdmin = require("firebase-admin");
const { handleErrors } = require("../../utils/ErrorHandler");

const app = firebaseAdmin.app();
const db = app.database();

class RealtimeDBService {
    constructor(ref) {
        this.db = db.ref(ref);
    }

    async addData(path, data) {
        try {
            await this.db.child(path).push(data);
            return 1;
        } catch (error) {
            handleErrors(error);
        }
    }

    async getData(path) {
        try {
            const snapshot = await this.db.child(path).once("value");
            return snapshot.val();
        } catch (error) {
            handleErrors(error);
        }
    }

    async updateData(path, data) {
        try {
            const snapshot = await this.db.child(path).update(data);
            return snapshot;
        } catch (error) {
            handleErrors(error);
        }
    }

    async deleteData(path) {
        try {
            const snapshot = await this.db.child(path).remove();
            return snapshot;
        } catch (error) {
            handleErrors(error);
        }
    }
}

exports.initRealtimeDB = (path) => {
    return new RealtimeDBService(path);
};
