const firebaseAdmin = require("firebase-admin");
const { handleErrors } = require("../../utils/ErrorHandler");

const app = firebaseAdmin.app();
const db = app.storage();

class StorageService {
    constructor() {
        this.db = db.bucket();
    }

    async uploadFile(file, path) {
        try {
            const res = await this.db.upload(file, {
                destination: path,
            });
            console.log(res);
            return res;
        } catch (error) {
            console.log(error);
            handleErrors(error);
        }
    }

    async getFile(path) {
        try {
            const res = await this.db.file(path).getSignedUrl({
                action: "read",
                expires: "03-09-2491",
            });
            console.log(res);
            return res;
        } catch (error) {
            handleErrors(error);
        }
    }
}

exports.initStorage = () => {
    return new StorageService();
};
