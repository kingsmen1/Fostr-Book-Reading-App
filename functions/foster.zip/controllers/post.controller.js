const PostService = require("../services/post.service");
const { sendSuccess, catchError } = require("../utils/RequestHandler");

exports.comments_post = async (req, res) => {
    const { postId, comment } = req.body;

    try {
        const result = await PostService.addComment(postId, comment);
        return sendSuccess(req, res)(result);
    } catch (error) {
        catchError(req, res, error);
    }
};

exports.comments_get = async (req, res) => {
    const { id } = req.params;

    try {
        const result = await PostService.getAllComments(id);
        return sendSuccess(req, res)(result);
    } catch (error) {
        catchError(req, res, error);
    }
};

exports.comments_delete = async (req, res) => {
    const { id, comment } = req.params;

    try {
        const result = await PostService.removeComment(id, comment);
        return sendSuccess(req, res)(result);
    } catch (error) {
        catchError(req, res, error);
    }
};

exports.likes_post = async (req, res) => {
    const { postId, like, userId } = req.body;

    try {
        const result = await PostService.addLike(userId, postId, like);
        return sendSuccess(req, res)(result);
    } catch (error) {
        catchError(req, res, error);
    }
};

exports.likes_get = async (req, res) => {
    const { id } = req.params;

    try {
        const result = await PostService.getAllLikes(id);
        return sendSuccess(req, res)(result);
    } catch (error) {
        catchError(req, res, error);
    }
};
exports.likes_delete = async (req, res) => {
    const { postId, userId } = req.params;

    try {
        const result = await PostService.removeLike(postId, userId);
        return sendSuccess(req, res)(result);
    } catch (error) {
        catchError(req, res, error);
    }
};

exports.posts_post = async (req, res) => {
    try {
        const data = req.body
        data["dateTime"] = new Date(data["dateTime"]);
        const result = await PostService.addPost(data);
        return sendSuccess(req, res)(result);
    } catch (error) {
        catchError(req, res, error);
    }
};

exports.posts_delete = async (req, res) => {
    const { id } = req.params;

    try {
        const result = await PostService.deletePosts(id);
        return sendSuccess(req, res)(result);
    } catch (error) {
        catchError(req, res, error);
    }
};

exports.posts_get = async (req, res) => {
    try {
        const result = await PostService.getAllPosts();
        return sendSuccess(req, res)(result);
    } catch (error) {
        catchError(req, res, error);
    }
};
