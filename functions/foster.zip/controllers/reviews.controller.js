const ReviewsService = require("../services/review.service");
const { sendSuccess, catchError } = require("../utils/RequestHandler");

exports.comments_post = async (req, res) => {
    const { postId, comment } = req.body;

    try {
        const result = await ReviewsService.addComment(postId, comment);
        return sendSuccess(req, res)(result);
    } catch (error) {
        catchError(req, res, error);
    }
};

exports.comments_get = async (req, res) => {
    const { id } = req.params;

    try {
        const result = await ReviewsService.getAllComments(id);
        return sendSuccess(req, res)(result);
    } catch (error) {
        catchError(req, res, error);
    }
};

exports.comments_delete = async (req, res) => {
    const { id, comment } = req.params;

    try {
        const result = await ReviewsService.removeComment(id, comment);
        return sendSuccess(req, res)(result);
    } catch (error) {
        catchError(req, res, error);
    }
};

exports.likes_post = async (req, res) => {
    const { postId, like, userId } = req.body;

    try {
        const result = await ReviewsService.addLike(userId, postId, like);
        return sendSuccess(req, res)(result);
    } catch (error) {
        catchError(req, res, error);
    }
};

exports.likes_get = async (req, res) => {
    const { id } = req.params;

    try {
        const result = await ReviewsService.getAllLikes(id);
        return sendSuccess(req, res)(result);
    } catch (error) {
        catchError(req, res, error);
    }
};

exports.likes_delete = async (req, res) => {
    const { postId, userId } = req.params;

    try {
        const result = await ReviewsService.removeLike(postId, userId);
        return sendSuccess(req, res)(result);
    } catch (error) {
        catchError(req, res, error);
    }
};

exports.reviews_post = async (req, res) => {
    try {
        const data = req.body
        data["dateTime"] = new Date(data["dateTime"]);
        const result = await ReviewsService.addReview(data);
        return sendSuccess(req, res)(result);
    } catch (error) {
        catchError(req, res, error);
    }
};

exports.reviews_delete = async (req, res) => {
    const { id } = req.params;

    try {
        const result = await ReviewsService.deleteReview(id);
        return sendSuccess(req, res)(result);
    } catch (error) {
        catchError(req, res, error);
    }
};


exports.reviews_get = async (req, res) => {
    try {
        const result = await ReviewsService.getAllReviews();
        return sendSuccess(req, res)(result);
    } catch (error) {
        catchError(req, res, error);
    }
}
