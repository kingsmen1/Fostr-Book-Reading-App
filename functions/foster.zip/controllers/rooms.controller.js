const RoomService = require("../services/room.service");

exports.room_post = async (req, res) => {
    try {
        const data = req.body
        data["dateTime"] = new Date(data["dateTime"]);
        const result = await RoomService.addRoom(data);
        res.status(200).json(result);
    } catch (error) {
        res.status(500).json(error);
    }
};

exports.room_get = async (req, res) => {
    try {
        const result = await RoomService.getRoom(
            req.params.userId,
            req.params.roomId
        );
        res.status(200).json(result);
    } catch (error) {
        res.status(500).json(error);
    }
};

exports.room_delete = async (req, res) => {
    try {
        const result = await RoomService.deleteRoom(
            req.params.userId,
            req.params.roomId
        );
        res.status(200).json(result);
    } catch (error) {
        res.status(500).json(error);
    }
};

exports.speaker_post = async (req, res) => {
    try {
        const result = await RoomService.addRoomSpeaker(req.body);
        res.status(200).json(result);
    } catch (error) {
        res.status(500).json(error);
    }
};

exports.speakers_get = async (req, res) => {
    try {
        const result = await RoomService.getRoomSpeakers(
            req.params.userId,
            req.params.roomId
        );
        res.status(200).json(result);
    } catch (error) {
        res.status(500).json(error);
    }
};

exports.speakers_delete = async (req, res) => {
    try {
        const result = await RoomService.leaveSpeakerRoom({
            userId: req.params.userId,
            roomId: req.params.roomId,
            speaker: req.body,
        });
        res.status(200).json(result);
    } catch (error) {
        res.status(500).json(error);
    }
};

exports.participants_post = async (req, res) => {
    try {
        const result = await RoomService.addRoomParticipant(req.body);
        res.status(200).json(result);
    } catch (error) {
        res.status(500).json(error);
    }
};

exports.participants_get = async (req, res) => {
    try {
        const result = await RoomService.getRoomParticipants(
            req.params.userId,
            req.params.roomId
        );
        res.status(200).json(result);
    } catch (error) {
        res.status(500).json(error);
    }
};

exports.participants_delete = async (req, res) => {
    try {
        const result = await RoomService.leaveParticipantRoom({
            userId: req.params.userId,
            roomId: req.params.roomId,
            participant: req.body,
        });
        res.status(200).json(result);
    } catch (error) {
        res.status(500).json(error);
    }
};
