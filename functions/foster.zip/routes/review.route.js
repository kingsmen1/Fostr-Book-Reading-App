const express = require("express");
const ReviewController = require("../controllers/reviews.controller");

const router = express.Router();

router.route("/reviews").post(ReviewController.reviews_post).get(ReviewController.reviews_get);
router.route("/reviews/:id").delete(ReviewController.reviews_delete);

router.route("/comments").post(ReviewController.comments_post);
router.route("/comments/:id").get(ReviewController.comments_get);
router.route("/comments/:id/:comment").delete(ReviewController.comments_delete);

router.route("/likes").post(ReviewController.likes_post);
router.route("/likes/:id").get(ReviewController.likes_get);
router.route("/likes/:postId/:userId").delete(ReviewController.likes_delete);

module.exports = router;
