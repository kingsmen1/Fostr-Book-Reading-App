const express = require("express");
const PostController = require("../controllers/post.controller");

const router = express.Router();

router.route("/add").post(PostController.posts_post);
router.route("/all").get(PostController.posts_get);
router.route("/delete/:id").delete(PostController.posts_delete);

router.route("/comments").post(PostController.comments_post);
router.route("/comments/:id").get(PostController.comments_get);
router.route("/comments/:id/:comment").delete(PostController.comments_delete);

router.route("/likes").post(PostController.likes_post);
router.route("/likes/:id").get(PostController.likes_get);
router.route("/likes/:postId/:userId").delete(PostController.likes_delete);

module.exports = router;
