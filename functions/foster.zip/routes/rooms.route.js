const express = require("express");
const RoomController = require("../controllers/rooms.controller");
const router = express.Router();

router.route("/add").post(RoomController.room_post);
router.route("/room/:userId/:roomId").get(RoomController.room_get).delete(RoomController.room_delete);

router.route("/speakers").post(RoomController.speaker_post);
router
    .route("/speakers/:userId/:roomId")
    .get(RoomController.speakers_get)
    .delete(RoomController.speakers_delete);

router.route("/participants").post(RoomController.participants_post);
router
    .route("/participants/:userId/:roomId")
    .get(RoomController.participants_get)
    .delete(RoomController.participants_delete);

module.exports = router;
