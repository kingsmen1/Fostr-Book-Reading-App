const _ = require("lodash");

const catchError = (req, res, error) => {
    if (!error) error = new Error("Default error");
    sendError(req, res)(error);
};

const sendSuccess = (req, res, message, status) => {
    if (req.user) {
        id = req.user.id;
    }

    return (data, globalData) => {
        if (_.isUndefined(status)) {
            status = 200;
        }
        return res.status(status).json({
            status: "ok",
            message: message || "Success result",
            data,
            ...globalData,
        });
    };
};

const sendError = (req, res) => {
    if (req.user) {
        id = req.user.id;
    }

    return (error, globalData) => {
        return res.status(error.status || 500).json({
            status: "error",
            message: error.message || "Unhandled Error",
            error,
            ...globalData,
        });
    };
};

module.exports = {
    catchError,
    sendSuccess,
    sendError,
};
