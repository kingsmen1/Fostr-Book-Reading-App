const errors = require("../utils/errors");

/**
 * throwIf - helper function to throw error if condition is true
 * @param  {function} fn - function to check condition
 * @param  {error} error - error to throw
 * @return {function}  returns a function that throws error if condition is true or returns result
 */

const throwIf = (fn, error) => {
    return (result) => (fn(result) ? throwError(error)() : result);
};

/**
 * throwError - helper function to throw error
 * @param  {any} error - error to throw
 * @return {function}  returns a function that throws error
 */
const throwError = (error) => {
    return (e) => {
        if (!e) e = new Error(error.message || "Default Error");
        e.status = error.status;
        e.errorType = error.errorType;
        throw e;
    };
};

/**
 * handleErrors - a higher level function to handle errors
 * @param  {any} error - error to handle
 * @return null
 */
const handleErrors = (error) => {
    if (error.errorType) {
        throw error;
    } else if (error.name === "CastError" || error.name === "ValidationError") {
        return throwError(errors.BadRequest)(error);
    } else {
        return throwError(errors.InternalServerError)(error);
    }
};

module.exports = {
    throwIf,
    throwError,
    handleErrors,
};
