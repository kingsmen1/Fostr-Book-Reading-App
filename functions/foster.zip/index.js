const functions = require("firebase-functions");
const express = require("express");
const fileUpload = require("express-fileupload");
const admin = require("firebase-admin");
admin.initializeApp();

const auth = require("./middlewares/auth.middleware");

const ReviewRouter = require("./routes/review.route");
const PostRouter = require("./routes/post.route");
const RoomRouter = require("./routes/rooms.route");
const app = express();

app.use(auth);
app.use(fileUpload());
app.use("/fosterbits", ReviewRouter);
app.use("/posts", PostRouter);
app.use("/rooms", RoomRouter);

exports.foster = functions.https.onRequest(app);
