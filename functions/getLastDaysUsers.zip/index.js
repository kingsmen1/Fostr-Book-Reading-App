const functions = require("firebase-functions");
const admin = require("firebase-admin");
admin.initializeApp();
const auth = admin.app().auth();

exports.getUsers = functions.https.onRequest(async (req, res) => {
    // get all users who created account from email
    const users = await auth.listUsers();
    const data = users.users.filter((user) => !user.emailVerified);
    res.send(data);
});

exports.isUserExist = functions.https.onCall(async (data, ctx) => {
    const { phoneNumber } = data;
    try {
        const user = await auth.getUserByPhoneNumber(phoneNumber);
        if (!user) {
            return {
                isExist: false,
            };
        }
        return {
            isExist: true,
        };
    } catch (error) {
        return {
            isExist: false,
        };
    }
});
// lastSignInTime
exports.getLastDaysUsers = functions.https.onRequest(async (req, res) => {
    const { day } = req.body;
    const users = await auth.listUsers();
    const data = users.users;
    var uIds = [];
    const lastFiveDaysUsers = data.filter(
        (user) =>
            new Date(user.metadata.creationTime).getTime() >
            new Date().getTime() - parseInt(day) * 24 * 60 * 60 * 1000
    );

    lastFiveDaysUsers.sort(function(a, b){return new Date(b.metadata.creationTime) - new Date(a.metadata.creationTime)});

    lastFiveDaysUsers.forEach(element => {
        uIds.push(element['uid']);
    });
    res.send(uIds);
});
