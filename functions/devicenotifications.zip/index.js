const functions = require("firebase-functions");
const admin = require("firebase-admin");

admin.initializeApp({
    credential: admin.credential.applicationDefault(),
}
);



//const db = admin.firestore();
const fcm = admin.messaging();

//const users = db.collection("users");
//const bookclubs = db.collection("bookclubs");

const ICON =
    "https://firebasestorage.googleapis.com/v0/b/fostr2021.appspot.com/o/Foster%2Fnotification%2Flogo-min%20(1).png?alt=media&token=ce84f85e-2db7-4994-a986-13609377af5e";


exports.devicenotifications = functions.https.onRequest(async (request, response) => {
    try {
        console.log("token--------- "+request.body.data.tokens);
        console.log("userId--------- "+request.body.data.userId);
        console.log("roomId--------- "+request.body.data.roomId);
        console.log("roomName--------- "+request.body.data.roomName);
        console.log("authorName--------- "+request.body.data.authorName);
        // let payload = {};

        // const userId = request.body.data.userId;
        // const roomId = request.body.data.roomId;
        // const authorName = request.body.data.authorName;
        // const roomName = request.body.data.roomName;

        const notification = {
            title: "New room invite",
            body: `Conversation with ${request.body.data.authorName} at ${request.body.data.roomName} is live. Tune in now!`,
            icon: ICON,
            collapse_key: "new_room_invite",
            tag: "new_room_invite",
        };

        const userId = request.body.data.userId;
        const roomId = request.body.data.roomId;

        const payload = {
            notification,
            data: {
                body: notification.body,
                type: "RoomUpdates",
                eventType: "room",
                "userID":userId,
                "typeID":roomId,
            },
        };

        fcm.sendToDevice(request.body.data.tokens, payload)
        .then(devicesResponse => {
        response.send(devicesResponse);
            })
        .catch((error) => {
            console.log("Error sending message:", error);
        });
        return 1;
    } catch (error) {
        console.log(error);
        response.send("notification not sent");
        return 0;
    }
    response.send(result);
});



