const functions = require("firebase-functions");
const admin = require("firebase-admin");

admin.initializeApp({
    credential: admin.credential.applicationDefault(),
});

const db = admin.firestore();
const fcm = admin.messaging();

const users = db.collection("users");
const ICON =
    "https://firebasestorage.googleapis.com/v0/b/fostr2021.appspot.com/o/Foster%2Fnotification%2Flogo-min%20(1).png?alt=media&token=ce84f85e-2db7-4994-a986-13609377af5e";

const sendFollowNotifications = async (data) => {
    try {
        let payload = {};

        let notification = {
            title: "New follower",
            body: `Your community is growing! ${data.userName} is now following you`,
            icon: ICON,
            collapse_key: "new_follower",
            tag: "new_follower",
        };

        payload = {
            notification,
            data: {
                type: "Follow",
                body: notification.body,
                userId: data.userId,
            },
        };

        fcm.sendToDevice(data.tokens, payload).catch((error) => {
            console.log("Error sending message:", error);
        });

        fcm.subscribeToTopic(data.currentToken, data.followedUserId);

        // const userId = data.userId;

        // const condition = `"otherNotification" in topics && "${userId}" in topics`;

        // notification = {
        //     title: "Followers",
        //     body: `${data.userName} is now following ${data.followedUserName}`,
        // };

        // try {
        //     await fcm.sendToCondition(condition, { notification });
        // } catch (error) {
        //     console.log("error happend", error);
        // }

        return 1;
    } catch (error) {
        console.log(error);
        return 0;
    }
};

const sendRoomInviteNotifications = async (data) => {
    try {
        let payload = {};

        let notification = {
            title: "New room invite",
            body: `A new door has opened for you! ${data.userName} has invited you to join their room`,
            icon: ICON,
            collapse_key: "new_room_invite",
            tag: "new_room_invite",
        };

        payload = {
            notification,
            data: {
                body: notification.body,
            },
        };

        fcm.sendToDevice(data.tokens, payload).catch((error) => {
            console.log("Error sending message:", error);
        });
        return 1;
    } catch (error) {
        console.log(error);
        return 0;
    }
};

const sendLikeNotifications = async (data) => {
    try {
        let payload = {};

        let notification = {
            title: "New Bookmark",
            body: `${data.userName} bookmarked your post`,
            icon: ICON,
            collapse_key: "new_bookmark",
            tag: "new_bookmark",
        };

        payload = {
            notification,
            data: {
                body: notification.body,
            },
        };

        fcm.sendToDevice(data.tokens, payload).catch((error) => {
            console.log("Error sending message:", error);
        });

        return 1;
    } catch (error) {
        console.log(error);
        return 0;
    }
};

const sendCommentNotifications = async (data) => {
    try {
        let payload = {};

        let notification = {
            title: "New comment",
            body: `Your post has a new comment from ${data.userName}`,
            icon: ICON,
            collapse_key: "new_comment",
            tag: "new_comment",
        };

        payload = {
            notification,
            data: {
                body: notification.body,
            },
        };

        fcm.sendToDevice(data.tokens, payload).catch((error) => {
            console.log("Error sending message:", error);
        });

        return 1;
    } catch (error) {
        console.log(error);
        return 0;
    }
};

const sendRatingNotifications = async (data) => {
    try {
        let payload = {};

        let notification = {
            title: "New rating",
            body: `Your bit has received new ratings!`,
            icon: ICON,
            collapse_key: "new_rating",
            tag: "new_rating",
        };

        payload = {
            notification,
            data: {
                body: notification.body,
            },
        };

        fcm.sendToDevice(data.tokens, payload).catch((error) => {
            console.log("Error sending message:", error);
        });

        return 1;
    } catch (error) {
        console.log(error);
        return 0;
    }
};

const sendReviewNotifications = async (data) => {
    try {
        let payload = {};

        let notification = {
            title: "New review",
            body: `Your bit has received a new review!`,
            icon: ICON,
            collapse_key: "new_review",
            tag: "new_review",
        };

        payload = {
            notification,
            data: {
                body: notification.body,
            },
        };

        fcm.sendToDevice(data.tokens, payload).catch((error) => {
            console.log("Error sending message:", error);
        });

        return 1;
    } catch (error) {
        console.log(error);
        return 0;
    }
};

const sendBookclubInvitationRequestNotifications = async (data) => {
    try {
        let payload = {};

        let notification = {
            title: "New Bookclub Invitation Request",
            body: `${data.userName} has requested to join your ${data.bookclubName}`,
            icon: ICON,
            collapse_key: "new_bookclub_invitation_request",
            tag: "new_bookclub_invitation_request",
        };

        payload = {
            notification,
            data: {
                body: notification.body,
            },
        };

        fcm.sendToDevice(data.tokens, payload).catch((error) => {
            console.log("Error sending message:", error);
        });

        return 1;
    } catch (error) {
        console.log(error);
        return 0;
    }
};

const sendBookclubInvitationAcceptedNotifications = async (data) => {
    try {
        let payload = {};

        let notification = {
            title: "Bookclub joining request status",
            body: data.title,
            icon: ICON,
            collapse_key: "new_bookclub_invitation_accepted",
            tag: "new_bookclub_invitation_accepted",
        };

        payload = {
            notification,
            data: {
                body: notification.body,
            },
        };

        fcm.sendToDevice(data.tokens, payload).catch((error) => {
            console.log("Error sending message:", error);
        });

        return 1;
    } catch (error) {
        console.log(error);
        return 0;
    }
}

exports.notifications = functions.https.onCall(async (data, context) => {
    if (!context.auth) {
        throw new functions.https.HttpsError(
            "failed-precondition",
            "The function must be called " + "while authenticated."
        );
    }
    const notificationId = parseInt(data.notificationId);
    switch (notificationId) {
        case 0:
            const res = await sendFollowNotifications(data);
            return { res };
        case 1:
            const res1 = await sendRoomInviteNotifications(data);
            return { res1 };
        case 2:
            const res2 = await sendLikeNotifications(data);
            return { res2 };

        // case 3:
        //     const res3 = await sendCommentNotifications(data);
        //     return { res3 };

        case 4:
            const res4 = await sendCommentNotifications(data);
            return { res4 };

        case 5:
            const res5 = await sendReviewNotifications(data);
            return { res5 };

        case 6:
            const res6 = await sendRatingNotifications(data);
            return { res6 };

        case 7:
            const res7 = await sendBookclubInvitationRequestNotifications(data);
            return { res7 };
        
        case 8:
            const res8 = await sendBookclubInvitationAcceptedNotifications(data);
            return { res8 };

        default:
            return { res: 0 };
    }
});

exports.reviewCreateNotification = functions.firestore
    .document("reviews/{id}")
    .onCreate(async (snap, context) => {
        const id = context.params.id;
        const review = snap.data();
        const userId = review.editorId;
        const condition = `"otherNotification" in topics && "${userId}" in topics`;

        const rawUser = await users.doc(userId).get();
        const user = rawUser.data();

        let notification = {
            title: "New Foster Bits",
            body: `Your feed has a new bit by ${data.userName}!`,
            collapse_key: "new_review",
            tag: "new_review",
        };

        try {
            await fcm.sendToCondition(condition, {
                notification,
                data: {
                    type: "Event",
                    eventType: "review",
                    userId,
                    reviewId: id,
                },
            });
        } catch (error) {
            console.log("error happend", error);
        }

        const dateTime = new Date(Date.now());

        const followings = user.followers || [];
        const res = await Promise.all(
            followings.map(async (following) => {
                users
                    .doc(following)
                    .collection("notifications")
                    .add({
                        read: false,
                        type: "Event",
                        title: review.bookName,
                        senderUserId: userId,
                        body: `${user.userName} has created a new bit on Book ${review.bookName}`,
                        payload: {
                            type: "Review",
                            reviewId: id,
                            userId: userId,
                        },
                        dateTime,
                    });
            })
        );
    });

exports.postCreateNotification = functions.firestore
    .document("posts/{id}")
    .onCreate(async (snap, context) => {
        const id = context.params.id;
        const post = snap.data();
        const userId = post.userid;
        const condition = `"otherNotification" in topics && "${userId}" in topics`;

        const rawUser = await users.doc(userId).get();
        const user = rawUser.data();

        let notification = {
            title: "New Post",
            body: `Your feed has a new reading by ${data.userName}!`,
            collapse_key: "new_post",
            tag: "new_post",
        };

        try {
            await fcm.sendToCondition(condition, {
                notification,
                data: {
                    type: "Event",
                    eventType: "post",
                    userId,
                    postId: id,
                },
            });
        } catch (error) {
            console.log("error happend", error);
        }

        const dateTime = new Date(Date.now());

        const followings = user.followers || [];
        const res = await Promise.all(
            followings.map(async (following) => {
                users
                    .doc(following)
                    .collection("notifications")
                    .add({
                        read: false,
                        type: "Event",
                        title: "New Post",
                        senderUserId: userId,
                        body: `${user.userName} has created a new reading`,
                        payload: {
                            type: "Post",
                            postId: id,
                            userId: userId,
                        },
                        dateTime,
                    });
            })
        );
    });

exports.roomCreateNotification = functions.firestore
    .document("rooms/{userId}/rooms/{roomId}")
    .onCreate(async (snap, context) => {
        const { userId, roomId } = context.params;

        const room = snap.data();
        const rawUser = await users.doc(userId).get();
        const user = rawUser.data();

        const condition = `"otherNotification" in topics && "${userId}" in topics`;

        let notification = {
            title: "New Room",
            body: `We see a new room! ${user.userName} has created a new room ${room.title}`,
            collapse_key: "new_room",
            tag: "new_room",
        };

        try {
            await fcm.sendToCondition(condition, {
                notification,
                data: {
                    type: "Event",
                    eventType: "room",
                    userId,
                    roomId,
                },
            });
        } catch (error) {
            console.log("error happend", error);
        }

        const dateTime = new Date(Date.now());

        const followings = user.followers || [];
        const res = await Promise.all(
            followings.map(async (following) => {
                users
                    .doc(following)
                    .collection("notifications")
                    .add({
                        read: false,
                        type: "Event",
                        title: room.title,
                        senderUserId: userId,
                        body: `${user.userName} has created a new room ${room.title}`,
                        payload: {
                            type: "Room",
                            roomId: roomId,
                            userId: userId,
                        },
                        dateTime,
                    });
            })
        );

        return 1;
    });

exports.bookClubCreateNotification = functions.firestore
    .document("rooms/{userId}/bookClub/{clubId}")
    .onCreate(async (snap, context) => {
        const { userId } = context.params;

        const room = snap.data();
        let user = await users.doc(userId).get();
        user = user.data();

        const condition = `"otherNotification" in topics && "${userId}" in topics`;

        let notification = {
            title: "New Room",
            body: `We see a new room! ${user.userName} has created a new room ${room.title}`,
        };

        try {
            await fcm.sendToCondition(condition, { notification });
        } catch (error) {
            console.log("error happend", error);
        }
        return 1;
    });
