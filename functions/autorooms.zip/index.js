const functions = require("firebase-functions");
const admin = require("firebase-admin");
const express = require("express");
const cors = require("cors");

admin.initializeApp();

const app = express();
const roomCollection="rooms";
const roomdocstructure={
  "authorName":"Sun Tzu" ,// string 
  "dateTime" : "timestamp", // timestamp
  "genre":"Action and Adventure", // string 
  "id":"User's ID", // string 
  "image":"imageurl", // string 
  "isActive":true,//boolean
  "isUpcoming":false,//boolean
  "lastTime":"timestamp" , // timestamp
  "participantsCount":0,//number
  "password":"",//string
  "roomCreator":"Rajesh R Rajamani",//string  
  "speakersCount":0,//number
  "title":"Art of War",//string 
  "token":"00658ee1103fa5b4a9e98e02bacc19aa826IABoRLeGHVyuRp4vAc2MIjJHkfOCfShz9+XKc0kXvf17z9Kr/E8AAAAAEACImw6VcRqiYQEAAQAAAAAA",//string
}


//create bulk rooms 
app.get("/v1/bulkrooms", async (req, res) => {
  const userid1="Le5gDAUkcggJWng4KHMNKTCdz6E3"
  const name1="Vidhya Damodaran"
  const userid2="4piQ493F1AbA9jd6MYu4LOg04pq1"
  const name2="Prabhu Subramanian"
  const userid3="DpFWnOIYqRasdBZWBeY34BMlpWt2"
  const name3="Varun Chopra"
  const userid4="ITSerT290iPEiQtgu7UrcoMCGdQ2"
  const name4="Rajesh Rajamani"
  const bookdatabase=
      [
          {
            "authorName":"Walter Issacson" ,// string 
            "dateTime" : "timestamp", // timestamp
            "genre":"Action and Adventure", // string 
            "id":userid1, // string 
            "image":"http://books.google.com/books/content?id=ZgrDRPlNNfQC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api", // string 
            "isActive":true,//boolean
            "isUpcoming":false,//boolean
            "lastTime":"timestamp" , // timestamp
            "participantsCount":0,//number
            "password":"",//string
            "roomCreator":name1,//string  
            "speakersCount":0,//number
            "title":"Steve Jobs",//string 
            "token":"00658ee1103fa5b4a9e98e02bacc19aa826IAAbgOf8UBL5x6ZwLNUpuBck5oEMsj5Tv8wozuvez0+riiAgSLsAAAAAEACXPvzXrHOjYQEAAQAAAAAA",//string
            },
          {
            "authorName":"James Clear" ,// string 
            "dateTime" : "timestamp", // timestamp
            "genre":"Self help", // string 
            "id":userid2, // string 
            "image":"http://books.google.com/books/content?id=fFCjDQAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api", // string 
            "isActive":true,//boolean
            "isUpcoming":false,//boolean
            "lastTime":"timestamp" , // timestamp
            "participantsCount":0,//number
            "password":"",//string
            "roomCreator":name2,//string  
            "speakersCount":0,//number
            "title":"Atomic Habits",//string 
            "token":"00658ee1103fa5b4a9e98e02bacc19aa826IABoRLeGHVyuRp4vAc2MIjJHkfOCfShz9+XKc0kXvf17z9Kr/E8AAAAAEACImw6VcRqiYQEAAQAAAAAA",//string
          },
          {
            "authorName":"Richard Branson" ,// string 
            "dateTime" : "timestamp", // timestamp
            "genre":"Biography", // string 
            "id":userid3,// string 
            "image":"http://books.google.com/books/content?id=eoZaDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api", // string 
            "isActive":true,//boolean
            "isUpcoming":false,//boolean
            "lastTime":"timestamp" , // timestamp
            "participantsCount":0,//number
            "password":"",//string
            "roomCreator":name3,//string  
            "speakersCount":0,//number
            "title":"Losing My Virginity",//string 
            "token":"00658ee1103fa5b4a9e98e02bacc19aa826IACcEE9RFVG7azxM9C2qKIiR/v3eRLSVzTW7+Lh0JRXIPJqRyXQAAAAAEACImw6V8hqiYQEAAQAAAAAA",//string
            
          },
          {
            "authorName":"Dean Nelson" ,// string 
            "dateTime" : "timestamp", // timestamp
            "genre":"Self help", // string 
            "id":userid4, // string 
            "image":"http://books.google.com/books/content?id=IDYRvwEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api", // string 
            "isActive":true,//boolean
            "isUpcoming":false,//boolean
            "lastTime":"timestamp" , // timestamp
            "participantsCount":0,//number
            "password":"",//string
            "roomCreator":name4,//string  
            "speakersCount":0,//number
            "title":"Jugaad Yatra",//string 
            "token":"00658ee1103fa5b4a9e98e02bacc19aa826IAD5EawCu/zo///43516Y06FeMRHCDA4KdlPgQBmlfvhfq6XHvAAAAAAEACImw6VVBqiYQEAAQAAAAAA",//string            
          },
          {
            "authorName":"Robin Sharma" ,// string 
            "dateTime" : "timestamp", // timestamp
            "genre":"Self help", // string 
            "id":userid2, // string 
            "image":"http://books.google.com/books/content?id=7W9bDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api", // string 
            "isActive":true,//boolean
            "isUpcoming":false,//boolean
            "lastTime":"timestamp" , // timestamp
            "participantsCount":0,//number
            "password":"",//string
            "roomCreator":name2,//string  
            "speakersCount":0,//number
            "title":"The 5 AM Club: Own Your Morning. Elevate Your Life.",//string 
            "token":"00658ee1103fa5b4a9e98e02bacc19aa826IACaVLI9bQ8jVlN8uAgt5AYoXSBi71MREwHHaRZAkh60bwx+f9gAAAAAEACr6+uk9H+PYQEAAQAAAAAA",//string
            
          },
          {
            "authorName":"Robin Sharma" ,// string 
            "dateTime" : "timestamp", // timestamp
            "genre":"Self help", // string 
            "id":userid3, // string 
            "image":"http://books.google.com/books/content?id=LjVw9YtC88sC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api", // string 
            "isActive":true,//boolean
            "isUpcoming":false,//boolean
            "lastTime":"timestamp" , // timestamp
            "participantsCount":0,//number
            "password":"",//string
            "roomCreator":name3,//string  
            "speakersCount":0,//number
            "title":"The Leader who had no title",//string 
            "token":"00658ee1103fa5b4a9e98e02bacc19aa826IABoRLeGHVyuRp4vAc2MIjJHkfOCfShz9+XKc0kXvf17z9Kr/E8AAAAAEACImw6VcRqiYQEAAQAAAAAA",//string
            
          },
          {
            "authorName":"MK Gandhi" ,// string 
            "dateTime" : "timestamp", // timestamp
            "genre":"Biography", // string 
            "id":userid1, // string 
            "image":"http://books.google.com/books/content?id=3IpZBgAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api", // string 
            "isActive":true,//boolean
            "isUpcoming":false,//boolean
            "lastTime":"timestamp" , // timestamp
            "participantsCount":0,//number
            "password":"",//string
            "roomCreator":name1,//string  
            "speakersCount":0,//number
            "title":"My Experiments with Truth",//string 
            "token":"00658ee1103fa5b4a9e98e02bacc19aa826IABoRLeGHVyuRp4vAc2MIjJHkfOCfShz9+XKc0kXvf17z9Kr/E8AAAAAEACImw6VcRqiYQEAAQAAAAAA",//string
            
          },
          {
            "authorName":"John Chambers" ,// string 
            "dateTime" : "timestamp", // timestamp
            "genre":"Self help", // string 
            "id":userid2, // string 
            "image":"http://books.google.com/books/content?id=DM-_tAEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api", // string 
            "isActive":true,//boolean
            "isUpcoming":false,//boolean
            "lastTime":"timestamp" , // timestamp
            "participantsCount":0,//number
            "password":"",//string
            "roomCreator":name2,//string  
            "speakersCount":0,//number
            "title":"Connecting the dots",//string 
            "token":"00658ee1103fa5b4a9e98e02bacc19aa826IABoRLeGHVyuRp4vAc2MIjJHkfOCfShz9+XKc0kXvf17z9Kr/E8AAAAAEACImw6VcRqiYQEAAQAAAAAA",//string
          },
          {
            "authorName":"Robert Kiyosaki" ,// string 
            "dateTime" : "timestamp", // timestamp
            "genre":"Self help", // string 
            "id":userid1, // string 
            "image":"http://books.google.com/books/content?id=myUCBQAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api", // string 
            "isActive":true,//boolean
            "isUpcoming":false,//boolean
            "lastTime":"timestamp" , // timestamp
            "participantsCount":0,//number
            "password":"",//string
            "roomCreator":name1,//string  
            "speakersCount":0,//number
            "title":"Rich Dad Poor Dad",//string 
            "token":"00658ee1103fa5b4a9e98e02bacc19aa826IABoRLeGHVyuRp4vAc2MIjJHkfOCfShz9+XKc0kXvf17z9Kr/E8AAAAAEACImw6VcRqiYQEAAQAAAAAA",//string            
          },
          {
            "authorName":"Stephen Covey" ,// string 
            "dateTime" : "timestamp", // timestamp
            "genre":"Self help", // string 
            "id":userid1, // string 
            "image":"http://books.google.com/books/content?id=08SoDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api", // string 
            "isActive":true,//boolean
            "isUpcoming":false,//boolean
            "lastTime":"timestamp" , // timestamp
            "participantsCount":0,//number
            "password":"",//string
            "roomCreator":name1,//string  
            "speakersCount":0,//number
            "title":"The 7 Habits of Highly Effective People",//string 
            "token":"00658ee1103fa5b4a9e98e02bacc19aa826IADjMWAS36xi42ty2iWAVrMznwlGdepxggqTuM8eP41M+UJANIcAAAAAEAAmxBWrfmObYQEAAQAAAAAA",//string            
          },
          {
            "authorName":"Prabhu Subramanian" ,// string 
            "dateTime" : "timestamp", // timestamp
            "genre":"Fiction", // string 
            "id":userid2, // string 
            "image":"https://firebasestorage.googleapis.com/v0/b/fostr2021.appspot.com/o/roomImage%2FPerfectly%20Imperfect.jpg?alt=media&token=847964bf-5aa3-499b-8062-421e703b3024", // string 
            "isActive":true,//boolean
            "isUpcoming":false,//boolean
            "lastTime":"timestamp" , // timestamp
            "participantsCount":0,//number
            "password":"",//string
            "roomCreator":name2,//string  
            "speakersCount":0,//number
            "title":"Perfectly Imperfect",//string 
            "token":"00658ee1103fa5b4a9e98e02bacc19aa826IAAIEiK/G5KGGlhHSlQeWWH4/O8kd3Gf73SQoR32VA0JzITVfAYAAAAAEACXPvzXanOjYQEAAQAAAAAA",//string            
          },
      ];

  /*    
  await admin.firestore().collection(roomCollection).doc(req.params.id).collection(roomCollection).add(room);
  */    
  
  const batch = admin.firestore().batch();  
  const db = admin.firestore();  
    bookdatabase.forEach((document) => {
      var docRef = db.collection("rooms").doc(document.id).collection("rooms").doc(); 
      //console.log(docRef.id)      
      //var now = new Date(new Date().toUTCString());
      //console.log(now);
      document["roomID"]=docRef.id; // add this to the document
      document["dateTime"]=new Date(new Date().toUTCString()); // ensure to add the current time
      //document["dateTime"]=new Date().toISOString(); // ensure to add 
      document["lastTime"]=new Date(new Date().toUTCString()); // ensure 
      //console.log(document)
      batch.set(docRef, document);
    });
    const result = await batch.commit();
  
  res.status(201).send(result)
});

//firebase functions route initialization
exports.autorooms = functions.https.onRequest(app);

// // Create and Deploy Your First Cloud Functions
// // https://firebase.google.com/docs/functions/write-firebase-functions
//
/*
exports.helloWorld = functions.https.onRequest((request, response) => {
  response.send("Hello from Firebase!");

});
*/