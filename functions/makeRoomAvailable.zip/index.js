const functions = require("firebase-functions");
const admin = require("firebase-admin");
const app = admin.initializeApp({});

const ICON =
    "https://firebasestorage.googleapis.com/v0/b/fostr2021.appspot.com/o/Foster%2Fnotification%2Flogo-min%20(1).png?alt=media&token=ce84f85e-2db7-4994-a986-13609377af5e";

const db = admin.firestore(app);
const fcm = admin.messaging();
const roomsCollection = db.collection("rooms");
const upcomingRoomsCollection = db.collection("upcomingRooms");
const feedsCollection = db.collection("feeds");
const feedArchiveCollection = db.collection("feeds-archive");

exports.makeRoomAvailable = functions.https.onRequest(async (req, res) => {
    try {
        const now = admin.firestore.Timestamp.now();
        const afterFiveMinute = admin.firestore.Timestamp.fromMillis(
            now.toMillis() + 300000
        );

        const upcomingRooms = await upcomingRoomsCollection
            .where("dateTime", ">=", now)
            .where("dateTime", "<=", afterFiveMinute)
            .get();
        upcomingRooms.forEach(async (doc) => {
            const upcomingRoom = doc.data();
            if (upcomingRoom.isAmphitheatre) {
                await roomsCollection
                    .doc(upcomingRoom.userId)
                    .collection("amphitheatre")
                    .doc(upcomingRoom.roomId)
                    .update({
                        isUpcoming: false,
                    });
            } else {
                const roomRef = roomsCollection
                    .doc(upcomingRoom.userId)
                    .collection("rooms")
                    .doc(upcomingRoom.roomId);
                const room = await roomRef.get();
                const roomData = room.data();
                roomRef.update({
                    isUpcoming: false,
                });
                await feedsCollection.add({
                    data: {
                        userId: upcomingRoom.userId,
                    },
                    dateTime: admin.firestore.Timestamp.now(),
                    id: upcomingRoom.roomId,
                    idType: "rooms",
                    isActive: true,
                    objectType: "room",
                });
                const condition = `"otherNotification" in topics && "${upcomingRoom.userId}" in topics`;

                let notification = {
                    title: "Room is available",
                    body: `${roomData.roomCreator}'s Room ${roomData.title} is available now!`,
                };
                try {
                    await fcm.sendToCondition(condition, {
                        notification,
                        data: {
                            type: "Event",
                            eventType: "room",
                            userId: upcomingRoom.userId,
                            roomId: upcomingRoom.roomId,
                        },
                    });
                } catch (error) {
                    console.log("error happend", error);
                }
            }
            await upcomingRoomsCollection.doc(doc.id).delete();
        });
        return res.send("Success");
    } catch (error) {
        console.log(error);
        return res.send(error);
    }
});

exports.clearFeeds = functions.https.onRequest(async (req, res) => {
    try {
        const feeds = await feedsCollection
            .where("dateTime", "<=", admin.firestore.Timestamp.now())
            .get();
        feeds.forEach(async (doc) => {
            await feedArchiveCollection.doc(doc.id).set(doc.data());
            await doc.ref.delete();
        });
        return res.send("Success");
    } catch (error) {
        console.log(error);
        return res.send(error);
    }
});
