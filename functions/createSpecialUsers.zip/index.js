const functions = require("firebase-functions");
const admin = require("firebase-admin");

admin.initializeApp({
    credential: admin.credential.applicationDefault(),
}
);

const userCollection = "users";

//create new speacial user
app.post("/create/:userid", async (req, res) => {

    try {
        const user = req.body;
        await admin
            .firestore()
            .collection(userCollection)
            .doc(req.params.userid)
            .set(user);

        res.status(201).send("ok");
    } catch (e) {
        functions.logger.log(e);
        res.status(404).send(e);
    }
});

//firebase functions route initialization
exports.createSpecialUsers = functions.https.onRequest(app);

