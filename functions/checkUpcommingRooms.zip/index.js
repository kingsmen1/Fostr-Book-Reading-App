const functions = require("firebase-functions");
const admin = require("firebase-admin");
const app = admin.initializeApp({});
const db = admin.firestore(app);
const upcomingRoomsCollection = db.collection("upcomingRooms");
const roomsCollection = db.collection("rooms");

exports.checkUpcomingRooms = functions.https.onRequest(async (req, res) => {
    const { date } = req.body;

    const rooms = await upcomingRoomsCollection
        .doc(date)
        .collection("rooms")
        .get();

    rooms.forEach(async (room) => {
        const roomData = room.data();
        const time = roomData.time;
        const minutes = time.substring(3);
        const hours = time.substring(0, 2);
        const month = date.substring(5, 7);
        const day = date.substring(8);

        const cronTime = `${minutes} ${hours} ${day} ${month} *`;

        functions.pubsub
            .schedule(cronTime)
            .timeZone("India/Kolkata")
            .onRun(async (scheduleContext) => {
                const myRoom = await roomsCollection
                    .doc(roomData.creatorId)
                    .collection("rooms")
                    .doc(roomData.id)
                    .get();
                if (myRoom.exists) {
                    myRoom.ref.update({
                        isAvailable: true,
                    });
                }
            });
    });
    res.send("done");
});
