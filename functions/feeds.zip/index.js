const functions = require("firebase-functions");
const admin = require("firebase-admin");
const express = require("express");

admin.initializeApp();
const app = express();
const auth = require("./middlewares/auth.middleware");

// app.use(auth);
app.use(express.json());

const feedCollection = admin.firestore().collection("feeds");
const feedArchiveCollection = admin.firestore().collection("feeds-archive");
const postCollection = admin.firestore().collection("posts");
const roomCollection = admin.firestore().collectionGroup("rooms");
const reviewCollection = admin.firestore().collection("reviews");
const theatreCollection = admin.firestore().collectionGroup("amphitheatre");
const datalimitDays = parseInt(process.env.DATA_LIMIT_DAYS); // to limit the number of days of data to be shown in the feed in initial fetch .
// const datalimitDays = 10;

app.route("/")
    .get(async (_, res) => {
        try {
            const docs = await feedCollection
                .where(
                    "dateTime",
                    ">=",
                    new Date(Date.now() - datalimitDays * 24 * 60 * 60 * 1000)
                )
                .orderBy("dateTime", "desc")
                .limit(100)
                .get();

            const allFeeds = [];

            const feeds = docs.docs.map((doc) => doc.data());

            const postIds = feeds
                .filter((feed) => feed.objectType === "post")
                .map((feed) => feed.id);

            if (postIds.length > 0) {
                if (postIds.length < 10) {
                    const posts = await postCollection
                        .where("id", "in", postIds)
                        .get();
                    const postData = posts.docs.map((doc) => {
                        return {
                            type: "post",
                            data: doc.data(),
                        };
                    });
                    allFeeds.push(...postData);
                } else {
                    const postIdArrays = [];
                    for (let i = 0; i < postIds.length; i += 10) {
                        if (i + 10 < postIds.length) {
                            postIdArrays.push(postIds.slice(i, i + 10));
                        } else {
                            postIdArrays.push(postIds.slice(i));
                        }
                    }
                    const postData = await Promise.all(
                        postIdArrays.map(async (postIdArray) => {
                            const posts = await postCollection
                                .where("id", "in", postIdArray)
                                .get();
                            return posts.docs.map((doc) => {
                                return {
                                    type: "post",
                                    data: doc.data(),
                                };
                            });
                        })
                    );
                    allFeeds.push(...postData.flat());
                }
            }

            const reviewsIds = feeds
                .filter((feed) => feed.objectType === "review")
                .map((feed) => feed.id);

            if (reviewsIds.length > 0) {
                if (reviewsIds.length < 10) {
                    const reviews = await reviewCollection
                        .where("id", "in", reviewsIds)
                        .get();
                    const reviewData = reviews.docs.map((doc) => {
                        return {
                            type: "review",
                            data: doc.data(),
                        };
                    });
                    allFeeds.push(...reviewData);
                } else {
                    const reviewIdArrays = [];
                    for (let i = 0; i < reviewsIds.length; i += 10) {
                        if (i + 10 < reviewsIds.length) {
                            reviewIdArrays.push(reviewsIds.slice(i, i + 10));
                        } else {
                            reviewIdArrays.push(reviewsIds.slice(i));
                        }
                    }
                    const reviewData = await Promise.all(
                        reviewIdArrays.map(async (reviewIdArray) => {
                            const reviews = await reviewCollection
                                .where("id", "in", reviewIdArray)
                                .get();
                            return reviews.docs.map((doc) => {
                                return {
                                    type: "review",
                                    data: doc.data(),
                                };
                            });
                        })
                    );
                    allFeeds.push(...reviewData.flat());
                }
            }

            const allRoomIds = feeds
                .filter((feed) => feed.objectType === "room")
                .map((feed) => feed.id);

            if (allRoomIds.length > 0) {
                if (allRoomIds.length < 10) {
                    const rooms = await roomCollection
                        .where("roomID", "in", allRoomIds)
                        .where(
                            "dateTime",
                            ">=",
                            new Date(new Date().getTime() - 10 * 60000)
                        )
                        .where(
                            "dateTime",
                            "<=",
                            new Date(new Date().getTime() + 90 * 60000)
                        )
                        .get();
                    const roomData = rooms.docs.map((doc) => {
                        return {
                            type: "room",
                            data: doc.data(),
                        };
                    });
                    allFeeds.push(...roomData);
                } else {
                    const roomIdArrays = [];
                    for (let i = 0; i < allRoomIds.length; i += 10) {
                        if (i + 10 < allRoomIds.length) {
                            roomIdArrays.push(allRoomIds.slice(i, i + 10));
                        } else {
                            roomIdArrays.push(allRoomIds.slice(i));
                        }
                    }
                    const roomData = await Promise.all(
                        roomIdArrays.map(async (roomIdArray) => {
                            const rooms = await roomCollection
                                .where("roomID", "in", roomIdArray)
                                .where(
                                    "dateTime",
                                    ">=",
                                    new Date(new Date().getTime() - 10 * 60000)
                                )
                                .where(
                                    "dateTime",
                                    "<=",
                                    new Date(new Date().getTime() + 90 * 60000)
                                )
                                .get();

                            return rooms.docs.map((doc) => {
                                return {
                                    type: "room",
                                    data: doc.data(),
                                };
                            });
                        })
                    );
                    allFeeds.push(...roomData.flat());
                }
            }
            const allTheatreIds = feeds
                .filter((feed) => feed.objectType === "theatre")
                .map((feed) => feed.id);

            if (allTheatreIds.length > 0) {
                if (allTheatreIds.length < 10) {
                    const theatres = await theatreCollection
                        .where("theatreId", "in", allTheatreIds)
                        .where(
                            "scheduledOn",
                            ">=",
                            new Date(new Date().getTime() - 10 * 60000)
                        )
                        .where(
                            "scheduledOn",
                            "<=",
                            new Date(new Date().getTime() + 90 * 60000)
                        )
                        .get();
                    const theatreData = theatres.docs.map((doc) => {
                        return {
                            type: "theatre",
                            data: doc.data(),
                        };
                    });
                    allFeeds.push(...theatreData);
                } else {
                    const theatreIdArrays = [];
                    for (let i = 0; i < allTheatreIds.length; i += 10) {
                        if (i + 10 < allTheatreIds.length) {
                            theatreIdArrays.push(
                                allTheatreIds.slice(i, i + 10)
                            );
                        } else {
                            theatreIdArrays.push(allTheatreIds.slice(i));
                        }
                    }
                    const theatreData = await Promise.all(
                        theatreIdArrays.map(async (theatreIdArray) => {
                            const theatres = await theatreCollection
                                .where("theatreId", "in", theatreIdArray)
                                .where(
                                    "scheduledOn",
                                    ">=",
                                    new Date(new Date().getTime() - 10 * 60000)
                                )
                                .where(
                                    "scheduledOn",
                                    "<=",
                                    new Date(new Date().getTime() + 90 * 60000)
                                )
                                .get();

                            return theatres.docs.map((doc) => {
                                return {
                                    type: "theatre",
                                    data: doc.data(),
                                };
                            });
                        })
                    );
                    allFeeds.push(...theatreData.flat());
                }
            }

            allFeeds.sort((a, b) => {
                if (a.type === "theatre") {
                    a.data.dateTime = a.data.scheduledOn;
                }
                if (b.type === "theatre") {
                    b.data.dateTime = b.data.scheduledOn;
                }
                return b.data.dateTime.toDate() - a.data.dateTime.toDate();
            });

            res.json(allFeeds);
        } catch (error) {
            console.log(error);
            res.status(500).json({ error: error.message });
        }
    })
    .post(async (req, res) => {
        try {
            const { id, idType, objectType, dateTime, ...data } = req.body;

            const docRef = await feedCollection.doc(id).create({
                id,
                idType,
                objectType,
                dateTime: new Date(dateTime),
                ...data,
            });

            res.send("ok");
        } catch (error) {
            console.log(error);
            res.status(500).send(error);
        }
    });

app.route("/:id").delete(async (req, res) => {
    try {
        const { id } = req.params;

        const doc = await feedCollection.doc(id).get();

        if (!doc.exists) {
            return res.status(404).send("not found");
        } else {
            await feedArchiveCollection.doc(id).set(doc.data());
            await doc.ref.delete();
            return res.send("deleted");
        }
    } catch (error) {
        console.log(error);
        res.status(500).send(error);
    }
});

exports.feeds = functions.https.onRequest(app);

// exports.updateDocs = functions.https.onRequest(async (req, res) => {
//     try {
//         admin
//             .firestore()
//             .collection("rooms")
//             .get()
//             .then(async (room) => {
//                 room.docs.forEach(async (doc) => {
//                     doc.ref
//                         .collection("rooms")
//                         .get()
//                         .then(async (rooms) => {
//                             rooms.docs.forEach((docRoom) => {
//                                 docRoom.ref.update({
//                                     summary: "",
//                                 });
//                             });
//                         });
//                 });
//             });
//         res.send("ok");
//     } catch (error) {
//         res.status(500).send(error);
//     }
// });
