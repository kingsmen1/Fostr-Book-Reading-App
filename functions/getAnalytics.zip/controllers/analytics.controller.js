const { BetaAnalyticsDataClient } = require("@google-analytics/data");

const client = new BetaAnalyticsDataClient({
    projectId: "fostr2021",
    keyFile: "./keyfile.json",
});

exports.getAnalytics = async ({ dateRanges, dimensions, metrics }) => {
    const [response] = await client.runReport({
        property: `properties/280351310`,
        dateRanges: dateRanges,
        dimensions: dimensions,
        metrics: metrics,
    });

    return response.rows;
};

// : [
//     {
//         startDate: "2020-03-31",
//         endDate: "today",
//     },
// ],

// : [
//     {
//         name: "city",
//     },
// ],

// : [
//     {
//         name: "activeUsers",
//     },
// ],
