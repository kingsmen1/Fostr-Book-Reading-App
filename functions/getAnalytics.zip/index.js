const functions = require("firebase-functions");
const { BetaAnalyticsDataClient } = require("@google-analytics/data");
const admin = require("firebase-admin");
admin.initializeApp({});

const client = new BetaAnalyticsDataClient({
    projectId: "fostr2021",
    keyFile: "./keyfile.json",
});

exports.getAnalytics = functions.https.onRequest(async (req, res) => {
    try {
        const body = JSON.parse(req.body);
        const { dateRanges, dimensions, metrics, ...other } = body;
        console.log(req.body);
        const [response] = await client.runReport({
            property: `properties/280351310`,
            dateRanges: dateRanges,
            dimensions: dimensions,
            metrics: metrics,
            ...other,
        });
        res.setHeader("Access-Control-Allow-Origin", "*");
        res.setHeader(
            "Access-Control-Allow-Headers",
            "Origin, X-Requested-With, Content-Type, Accept"
        );
        res.setHeader("Access-Control-Allow-Credentials", true);
        res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
        res.send(response.rows);
    } catch (error) {
        console.log(error);
        res.send(error);
    }
});
