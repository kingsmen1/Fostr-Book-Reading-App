const express = require("express");

const router = express.Router();

const { getAnalytics } = require("../controllers/analytics.controller");

router.route("/newusers").get(async (req, res) => {
    const { startDate, endDate, dimensions, metrics } = req.body;

    try {
        const result = await getAnalytics({
            dateRanges: [
                {
                    startDate,
                    endDate,
                },
            ],
            dimensions: [
                {
                    name: "city",
                },
                {
                    name: "country",
                },
                ...dimensions,
            ],
            metrics: [
                {
                    name: "newUsers",
                },
                ...metrics,
            ],
        });
        res.send(result);
    } catch (error) {
        console.log(error);
        res.send("error");
    }
});

router.route("/total-users").get(async (req, res) => {
    const { startDate, endDate, dimensions, metrics } = req.body;
    try {
        const result = await getAnalytics({
            dateRanges: [
                {
                    startDate,
                    endDate,
                },
            ],
            dimensions: [
                {
                    name: "platform",
                },
                {
                    name: "country",
                },
                {
                    name: "city",
                },
                ...dimensions,
            ],
            metrics: [
                {
                    name: "totalUsers",
                },
                ...metrics,
            ],
        });
        res.send(result);
    } catch (error) {
        console.log(error);
        res.send("error");
    }
});

router.route("/activeusers").get(async (req, res) => {
    const { startDate, endDate } = req.body;

    try {
        const result = await getAnalytics({
            dateRanges: [
                {
                    startDate,
                    endDate,
                },
            ],
            dimensions: [
                {
                    name: "city",
                },
                {
                    name: "country",
                },
            ],
            metrics: [
                {
                    name: "activeUsers",
                },
            ],
        });
        res.send(result);
    } catch (error) {
        console.log(error);
        res.send("error");
    }
});

module.exports = router;
