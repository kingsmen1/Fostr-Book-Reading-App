const functions = require("firebase-functions");
const admin = require("firebase-admin");
admin.initializeApp();

// global
const { Logging } = require("@google-cloud/logging");
const logging = new Logging();

exports.eventlogging = functions.https.onCall(async (data, context) => {
    const { roomId, creatorId, event, logLevel, roomUserId } = data;

    const Log = logging.log(`eventLogging/${creatorId}/${roomId}`);

    const logdata = { event, roomUserId, roomId, creatorId };
    const traceId =
        context.rawRequest.get("x-cloud-trace-context").split("/")[0] ||
        "got-nothing";
    const metadata = {
        severity: logLevel || "INFO",
        type: "cloud_function",
        labels: {
            project: process.env.GCLOUD_PROJECT,
            execution_id: context.rawRequest.get("function-execution-id"),
        },
        trace: `projects/${process.env.GCLOUD_PROJECT}/traces/${traceId}`,
    };
    Log.write(Log.entry(metadata, logdata));
    return 0;
});

/*

  sample query:

  severity= ${logLevel}
  resource.type="cloud_function"
  log_name="projects/fostr2021/logs/eventLogging%2F${creatorId}%2F${roomId}"
  resource.labels.function_name="eventlogging"
*/

exports.geteventlogs = functions.https.onRequest(async (req, res) => {
    const { roomId, creatorId } = req.body;
    const Log = logging.log(`eventLogging/${creatorId}/${roomId}`);
    const results = await Log.getEntries();
    res.send(results);
});
