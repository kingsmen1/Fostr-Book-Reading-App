const functions = require("firebase-functions");
const express = require("express");
const cors = require("cors");

const admin = require("firebase-admin");
admin.initializeApp();
const scheduler = require("@google-cloud/scheduler");

const schedulerClient = new scheduler.CloudSchedulerClient({
    projectId: "fostr2021",
    keyFile: "./keyfile.json",
});

const validateFirebaseIdToken = async (req, res, next) => {
    functions.logger.log(
        "Check if request is authorized with Firebase ID token"
    );

    if (
        (!req.headers.authorization ||
            !req.headers.authorization.startsWith("Bearer ")) &&
        !(req.cookies && req.cookies.__session)
    ) {
        functions.logger.error(
            "No Firebase ID token was passed as a Bearer token in the Authorization header.",
            "Make sure you authorize your request by providing the following HTTP header:",
            "Authorization: Bearer <Firebase ID Token>",
            'or by passing a "__session" cookie.'
        );
        res.status(403).send("Unauthorized");
        return;
    }

    let idToken;
    if (
        req.headers.authorization &&
        req.headers.authorization.startsWith("Bearer ")
    ) {
        functions.logger.log('Found "Authorization" header');
        // Read the ID Token from the Authorization header.
        idToken = req.headers.authorization.split("Bearer ")[1];
    } else if (req.cookies) {
        functions.logger.log('Found "__session" cookie');
        // Read the ID Token from cookie.
        idToken = req.cookies.__session;
    } else {
        // No cookie
        res.status(403).send("Unauthorized");
        return;
    }

    try {
        const decodedIdToken = await admin.auth().verifyIdToken(idToken);
        functions.logger.log("ID Token correctly decoded", decodedIdToken);
        req.user = decodedIdToken;
        next();
        return;
    } catch (error) {
        functions.logger.error(
            "Error while verifying Firebase ID token:",
            error
        );
        res.status(403).send("Unauthorized");
        return;
    }
};

const app = express();
//use
app.use(validateFirebaseIdToken);
const roomCollection = "rooms";
const userCollection = "users";
const amphitheatreCollection = "amphitheatre";

//create new amphitheater under user
app.post("/v1/create/:userid", async (req, res) => {
    const increment = admin.firestore.FieldValue.increment(1);
    //user document for update
    const docref = admin
        .firestore()
        .collection(userCollection)
        .doc(req.params.userid);

    try {
        const amphitheatre = req.body;
        amphitheatre["scheduledOn"] = new Date(amphitheatre["scheduledOn"]);
        const snapshot = await admin
            .firestore()
            .collection(roomCollection)
            .doc(req.params.userid)
            .collection(amphitheatreCollection)
            .add(amphitheatre)
            .then(
                docref.update({
                    totalAmphitheatres: increment,
                })
            );
        //console.log(snapshot.id);

        await admin
            .firestore()
            .collection(roomCollection)
            .doc(req.params.userid)
            .collection(amphitheatreCollection)
            .doc(snapshot.id)
            .update({ theatreId: snapshot.id });

        if (amphitheatre.isUpcoming) {
            await admin.firestore().collection("upcomingRooms").add({
                roomId: snapshot.id,
                userId: req.params.userid,
                dateTime: amphitheatre.scheduledOn,
                isAmphitheatre: true,
                isDone: false,
            });
        }

        res.status(201).json({
            message: "Amphitheatre created successfully",
            roomId: snapshot.id,
            userId: req.params.userid,
        });
    } catch (e) {
        functions.logger.log(e);
        res.status(404).send(e);
    }
});

//edit user status in amphitheatre
app.put("/v1/rooms/:ownerid/:theatreid/:userid", async (req, res) => {
    const body = req.body;
    try {
        /*
    const snapshot = await admin.firestore()
    .collectionGroup("users")  
    .where("userid","==",req.params.userid)
    .get()

    //console.log(snapshot);
    //console.log(snapshot.size);

    snapshot.forEach((doc) => {
        doc.ref.update(req.body)
      })
    */

        await admin
            .firestore()
            .collection(roomCollection)
            .doc(req.params.ownerid)
            .collection(amphitheatreCollection)
            .doc(req.params.theatreid)
            .collection("users")
            .doc(req.params.userid)
            .update(req.body);

        res.status(200).send();
    } catch (e) {
        functions.logger.log(e);
        res.status(404).send(e);
    }
});

//firebase functions route initialization
exports.amphitheatre = functions.https.onRequest(app);

// // Create and Deploy Your First Cloud Functions
// // https://firebase.google.com/docs/functions/write-firebase-functions
//
/*
exports.helloWorld = functions.https.onRequest((request, response) => {
  response.send("Hello from Firebase!");

});
*/
